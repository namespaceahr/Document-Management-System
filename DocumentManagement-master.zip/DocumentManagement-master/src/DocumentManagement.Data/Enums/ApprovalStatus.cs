﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DocumentManagement.Data.Enums
{
    public enum ApprovalStatus
    {
        PendingVerification = 1,
        PendingCorrection,
        Approved,
        Declined
    }
}
