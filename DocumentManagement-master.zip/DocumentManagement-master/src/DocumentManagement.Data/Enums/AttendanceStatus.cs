﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DocumentManagement.Data.Enums
{
    public enum AttendanceStatus
    {
        Attend,
        Absent,
        Leave
    }
}
