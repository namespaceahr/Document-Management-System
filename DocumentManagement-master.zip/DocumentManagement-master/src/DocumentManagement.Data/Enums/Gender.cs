﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DocumentManagement.Data.Enums
{
    public enum Gender
    {
        Male = 1,
        Female,
        Other
    }
}
