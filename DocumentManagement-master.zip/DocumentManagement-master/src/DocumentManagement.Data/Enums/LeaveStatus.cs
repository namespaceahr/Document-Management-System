﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DocumentManagement.Data.Enums
{
    public enum LeaveStatus
    {
        Pending = 1,
        Cancelled,
        Granted,
        Declined
    }
}
