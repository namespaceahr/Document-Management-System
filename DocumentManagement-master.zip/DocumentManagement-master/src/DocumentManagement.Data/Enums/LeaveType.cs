﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DocumentManagement.Data.Enums
{
    public enum LeaveType
    {
        SickLeave = 1,
        Vacation,
        Other
    }
}
