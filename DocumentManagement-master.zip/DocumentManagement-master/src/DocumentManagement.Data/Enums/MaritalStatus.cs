﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DocumentManagement.Data.Enums
{
    public enum MaritalStatus
    {
        Single = 1,
        Married,
        Divorced,
        Widowed
    }
}
