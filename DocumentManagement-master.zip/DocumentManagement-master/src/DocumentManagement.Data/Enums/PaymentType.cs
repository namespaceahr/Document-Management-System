﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DocumentManagement.Data.Enums
{
    public enum PaymentType
    {
        Cash = 1,
        Check
    }
}
