﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DocumentManagement.Data.Enums
{
    public enum Religion
    {
        Islam = 1,
        Hinduism,
        Christianity,
        Buddhism,
        Other
    }
}
