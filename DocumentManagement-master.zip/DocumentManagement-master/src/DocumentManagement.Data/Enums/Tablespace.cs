﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DocumentManagement.Data.Enums
{
    public enum Tablespace
    {
        Document,
        Department,
        Employee,
        AcademicInformation,
        PersonalInformation,
        SalaryGrade,
        WorkExperience
    }
}
