﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DocumentManagement.Data.Enums
{
    public enum TransactionType
    {
        Insert,
        Update,
        Delete
    }
}
