﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.EntityFrameworkCore.Metadata;

namespace DocumentManagement.Data.Migrations
{
    public partial class PIMSModelChanges : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Board",
                table: "AcademicInformations");

            migrationBuilder.RenameColumn(
                name: "Acievement",
                table: "TrainingInformations",
                newName: "Achievement");

            migrationBuilder.RenameColumn(
                name: "EmployeeName",
                table: "Employees",
                newName: "LastName");

            migrationBuilder.RenameColumn(
                name: "Degree",
                table: "AcademicInformations",
                newName: "Result");

            migrationBuilder.RenameColumn(
                name: "Cgpa",
                table: "AcademicInformations",
                newName: "Exam");

            migrationBuilder.AddColumn<string>(
                name: "NationalId",
                table: "PersonalInformations",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "FirstName",
                table: "Employees",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "References",
                columns: table => new
                {
                    Serial = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Designation = table.Column<string>(nullable: true),
                    Email = table.Column<string>(nullable: true),
                    EmployeeId = table.Column<string>(nullable: true),
                    Organization = table.Column<string>(nullable: true),
                    Phone = table.Column<string>(nullable: true),
                    Referee = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_References", x => x.Serial);
                    table.ForeignKey(
                        name: "FK_References_Employees_EmployeeId",
                        column: x => x.EmployeeId,
                        principalTable: "Employees",
                        principalColumn: "EmployeeId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_References_EmployeeId",
                table: "References",
                column: "EmployeeId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "References");

            migrationBuilder.DropColumn(
                name: "NationalId",
                table: "PersonalInformations");

            migrationBuilder.DropColumn(
                name: "FirstName",
                table: "Employees");

            migrationBuilder.RenameColumn(
                name: "Achievement",
                table: "TrainingInformations",
                newName: "Acievement");

            migrationBuilder.RenameColumn(
                name: "LastName",
                table: "Employees",
                newName: "EmployeeName");

            migrationBuilder.RenameColumn(
                name: "Result",
                table: "AcademicInformations",
                newName: "Degree");

            migrationBuilder.RenameColumn(
                name: "Exam",
                table: "AcademicInformations",
                newName: "Cgpa");

            migrationBuilder.AddColumn<string>(
                name: "Board",
                table: "AcademicInformations",
                nullable: true);
        }
    }
}
