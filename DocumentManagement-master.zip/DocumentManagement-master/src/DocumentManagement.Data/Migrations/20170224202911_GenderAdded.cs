﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore.Migrations;

namespace DocumentManagement.Data.Migrations
{
    public partial class GenderAdded : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "FirstName",
                table: "Employees");

            migrationBuilder.DropColumn(
                name: "LastName",
                table: "Employees");

            migrationBuilder.AddColumn<string>(
                name: "FirstName",
                table: "PersonalInformations",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Gender",
                table: "PersonalInformations",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "LastName",
                table: "PersonalInformations",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "FirstName",
                table: "PersonalInformations");

            migrationBuilder.DropColumn(
                name: "Gender",
                table: "PersonalInformations");

            migrationBuilder.DropColumn(
                name: "LastName",
                table: "PersonalInformations");

            migrationBuilder.AddColumn<string>(
                name: "FirstName",
                table: "Employees",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "LastName",
                table: "Employees",
                nullable: true);
        }
    }
}
