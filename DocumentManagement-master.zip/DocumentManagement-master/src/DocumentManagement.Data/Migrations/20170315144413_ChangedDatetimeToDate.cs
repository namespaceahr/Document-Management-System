﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore.Migrations;

namespace DocumentManagement.Data.Migrations
{
    public partial class ChangedDatetimeToDate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<DateTime>(
                name: "StartDate",
                table: "TrainingInformations",
                type: "Date",
                nullable: false);

            migrationBuilder.AlterColumn<DateTime>(
                name: "EndDate",
                table: "TrainingInformations",
                type: "Date",
                nullable: false);

            migrationBuilder.AlterColumn<DateTime>(
                name: "BirthDate",
                table: "PersonalInformations",
                type: "Date",
                nullable: false);

            migrationBuilder.AlterColumn<DateTime>(
                name: "JoiningDate",
                table: "Employees",
                type: "Date",
                nullable: false);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<DateTime>(
                name: "StartDate",
                table: "TrainingInformations",
                nullable: false);

            migrationBuilder.AlterColumn<DateTime>(
                name: "EndDate",
                table: "TrainingInformations",
                nullable: false);

            migrationBuilder.AlterColumn<DateTime>(
                name: "BirthDate",
                table: "PersonalInformations",
                nullable: false);

            migrationBuilder.AlterColumn<DateTime>(
                name: "JoiningDate",
                table: "Employees",
                nullable: false);
        }
    }
}
