﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore.Migrations;

namespace DocumentManagement.Data.Migrations
{
    public partial class ChangedEmployeeAddress : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_PersonalInformations_Addresses_PermanentAddressSerial",
                table: "PersonalInformations");

            migrationBuilder.DropForeignKey(
                name: "FK_PersonalInformations_Addresses_PresentAddressSerial",
                table: "PersonalInformations");

            migrationBuilder.DropIndex(
                name: "IX_PersonalInformations_PermanentAddressSerial",
                table: "PersonalInformations");

            migrationBuilder.DropColumn(
                name: "PermanentAddressSerial",
                table: "PersonalInformations");

            migrationBuilder.RenameColumn(
                name: "PresentAddressSerial",
                table: "PersonalInformations",
                newName: "AddressSerial");

            migrationBuilder.RenameIndex(
                name: "IX_PersonalInformations_PresentAddressSerial",
                table: "PersonalInformations",
                newName: "IX_PersonalInformations_AddressSerial");

            migrationBuilder.AddForeignKey(
                name: "FK_PersonalInformations_Addresses_AddressSerial",
                table: "PersonalInformations",
                column: "AddressSerial",
                principalTable: "Addresses",
                principalColumn: "Serial",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_PersonalInformations_Addresses_AddressSerial",
                table: "PersonalInformations");

            migrationBuilder.RenameColumn(
                name: "AddressSerial",
                table: "PersonalInformations",
                newName: "PresentAddressSerial");

            migrationBuilder.RenameIndex(
                name: "IX_PersonalInformations_AddressSerial",
                table: "PersonalInformations",
                newName: "IX_PersonalInformations_PresentAddressSerial");

            migrationBuilder.AddColumn<int>(
                name: "PermanentAddressSerial",
                table: "PersonalInformations",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_PersonalInformations_PermanentAddressSerial",
                table: "PersonalInformations",
                column: "PermanentAddressSerial");

            migrationBuilder.AddForeignKey(
                name: "FK_PersonalInformations_Addresses_PermanentAddressSerial",
                table: "PersonalInformations",
                column: "PermanentAddressSerial",
                principalTable: "Addresses",
                principalColumn: "Serial",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_PersonalInformations_Addresses_PresentAddressSerial",
                table: "PersonalInformations",
                column: "PresentAddressSerial",
                principalTable: "Addresses",
                principalColumn: "Serial",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
