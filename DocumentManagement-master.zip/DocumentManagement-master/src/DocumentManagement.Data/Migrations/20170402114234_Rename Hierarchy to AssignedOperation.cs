﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.EntityFrameworkCore.Metadata;

namespace DocumentManagement.Data.Migrations
{
    public partial class RenameHierarchytoAssignedOperation : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Hierarchies");

            migrationBuilder.CreateTable(
                name: "AssignedOperations",
                columns: table => new
                {
                    AssignedOperationId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    EmployeeId = table.Column<string>(nullable: true),
                    ModuleOperationId = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AssignedOperations", x => x.AssignedOperationId);
                    table.ForeignKey(
                        name: "FK_AssignedOperations_Employees_EmployeeId",
                        column: x => x.EmployeeId,
                        principalTable: "Employees",
                        principalColumn: "EmployeeId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_AssignedOperations_ModuleOperations_ModuleOperationId",
                        column: x => x.ModuleOperationId,
                        principalTable: "ModuleOperations",
                        principalColumn: "ModuleOperationId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_AssignedOperations_EmployeeId",
                table: "AssignedOperations",
                column: "EmployeeId");

            migrationBuilder.CreateIndex(
                name: "IX_AssignedOperations_ModuleOperationId",
                table: "AssignedOperations",
                column: "ModuleOperationId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AssignedOperations");

            migrationBuilder.CreateTable(
                name: "Hierarchies",
                columns: table => new
                {
                    HierarchyId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    EmployeeId = table.Column<string>(nullable: true),
                    ModuleOperationId = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Hierarchies", x => x.HierarchyId);
                    table.ForeignKey(
                        name: "FK_Hierarchies_Employees_EmployeeId",
                        column: x => x.EmployeeId,
                        principalTable: "Employees",
                        principalColumn: "EmployeeId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Hierarchies_ModuleOperations_ModuleOperationId",
                        column: x => x.ModuleOperationId,
                        principalTable: "ModuleOperations",
                        principalColumn: "ModuleOperationId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Hierarchies_EmployeeId",
                table: "Hierarchies",
                column: "EmployeeId");

            migrationBuilder.CreateIndex(
                name: "IX_Hierarchies_ModuleOperationId",
                table: "Hierarchies",
                column: "ModuleOperationId");
        }
    }
}
