﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.EntityFrameworkCore.Metadata;

namespace DocumentManagement.Data.Migrations
{
    public partial class ReceiptAndVoucherModels : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Receipts",
                columns: table => new
                {
                    ReceiptId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CreatorId = table.Column<string>(nullable: true),
                    Date = table.Column<DateTime>(type: "Date", nullable: false),
                    Description = table.Column<string>(nullable: true),
                    Items = table.Column<string>(nullable: true),
                    Note = table.Column<string>(nullable: true),
                    Organization = table.Column<string>(nullable: true),
                    PaymentInformation = table.Column<string>(nullable: true),
                    ProcurerId = table.Column<string>(nullable: true),
                    ReceiptNo = table.Column<int>(nullable: false),
                    Status = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Receipts", x => x.ReceiptId);
                    table.ForeignKey(
                        name: "FK_Receipts_Employees_CreatorId",
                        column: x => x.CreatorId,
                        principalTable: "Employees",
                        principalColumn: "EmployeeId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Receipts_Employees_ProcurerId",
                        column: x => x.ProcurerId,
                        principalTable: "Employees",
                        principalColumn: "EmployeeId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Vouchers",
                columns: table => new
                {
                    VoucherId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CreatorId = table.Column<string>(nullable: true),
                    Date = table.Column<DateTime>(type: "Date", nullable: false),
                    DepartmentId = table.Column<int>(nullable: false),
                    Description = table.Column<string>(nullable: true),
                    Items = table.Column<string>(nullable: true),
                    Note = table.Column<string>(nullable: true),
                    Organization = table.Column<string>(nullable: true),
                    ProcurerId = table.Column<string>(nullable: true),
                    Status = table.Column<int>(nullable: false),
                    VoucherNo = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Vouchers", x => x.VoucherId);
                    table.ForeignKey(
                        name: "FK_Vouchers_Employees_CreatorId",
                        column: x => x.CreatorId,
                        principalTable: "Employees",
                        principalColumn: "EmployeeId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Vouchers_Departments_DepartmentId",
                        column: x => x.DepartmentId,
                        principalTable: "Departments",
                        principalColumn: "DepartmentId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Vouchers_Employees_ProcurerId",
                        column: x => x.ProcurerId,
                        principalTable: "Employees",
                        principalColumn: "EmployeeId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Receipts_CreatorId",
                table: "Receipts",
                column: "CreatorId");

            migrationBuilder.CreateIndex(
                name: "IX_Receipts_ProcurerId",
                table: "Receipts",
                column: "ProcurerId");

            migrationBuilder.CreateIndex(
                name: "IX_Vouchers_CreatorId",
                table: "Vouchers",
                column: "CreatorId");

            migrationBuilder.CreateIndex(
                name: "IX_Vouchers_DepartmentId",
                table: "Vouchers",
                column: "DepartmentId");

            migrationBuilder.CreateIndex(
                name: "IX_Vouchers_ProcurerId",
                table: "Vouchers",
                column: "ProcurerId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Receipts");

            migrationBuilder.DropTable(
                name: "Vouchers");
        }
    }
}
