﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.EntityFrameworkCore.Metadata;

namespace DocumentManagement.Data.Migrations
{
    public partial class AddedPayrollEntity : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<decimal>(
                name: "Transportation",
                table: "SalaryGrades",
                nullable: false);

            migrationBuilder.AlterColumn<string>(
                name: "Others",
                table: "SalaryGrades",
                nullable: true);

            migrationBuilder.AlterColumn<decimal>(
                name: "MedicalAllowance",
                table: "SalaryGrades",
                nullable: false);

            migrationBuilder.AlterColumn<decimal>(
                name: "HouseRent",
                table: "SalaryGrades",
                nullable: false);

            migrationBuilder.AlterColumn<decimal>(
                name: "BasicSalary",
                table: "SalaryGrades",
                nullable: false);

            migrationBuilder.CreateTable(
                name: "Payrolls",
                columns: table => new
                {
                    PayrollId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    AccountNo = table.Column<string>(nullable: true),
                    BasicSalary = table.Column<decimal>(nullable: false),
                    DisbursementDate = table.Column<DateTime>(nullable: false),
                    EmployeeId = table.Column<string>(nullable: true),
                    HouseRent = table.Column<decimal>(nullable: false),
                    IncomeTax = table.Column<decimal>(nullable: false),
                    MedicalAllowance = table.Column<decimal>(nullable: false),
                    Month = table.Column<int>(nullable: false),
                    Others = table.Column<string>(nullable: true),
                    ProvidentFund = table.Column<decimal>(nullable: false),
                    Transportation = table.Column<decimal>(nullable: false),
                    UnpaidLeave = table.Column<decimal>(nullable: false),
                    Year = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Payrolls", x => x.PayrollId);
                    table.ForeignKey(
                        name: "FK_Payrolls_Employees_EmployeeId",
                        column: x => x.EmployeeId,
                        principalTable: "Employees",
                        principalColumn: "EmployeeId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Payrolls_EmployeeId",
                table: "Payrolls",
                column: "EmployeeId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Payrolls");

            migrationBuilder.AlterColumn<decimal>(
                name: "Transportation",
                table: "SalaryGrades",
                nullable: true);

            migrationBuilder.AlterColumn<decimal>(
                name: "Others",
                table: "SalaryGrades",
                nullable: true);

            migrationBuilder.AlterColumn<decimal>(
                name: "MedicalAllowance",
                table: "SalaryGrades",
                nullable: true);

            migrationBuilder.AlterColumn<decimal>(
                name: "HouseRent",
                table: "SalaryGrades",
                nullable: true);

            migrationBuilder.AlterColumn<decimal>(
                name: "BasicSalary",
                table: "SalaryGrades",
                nullable: true);
        }
    }
}
