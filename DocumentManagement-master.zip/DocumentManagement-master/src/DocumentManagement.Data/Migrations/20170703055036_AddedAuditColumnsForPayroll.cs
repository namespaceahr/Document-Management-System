﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore.Migrations;

namespace DocumentManagement.Data.Migrations
{
    public partial class AddedAuditColumnsForPayroll : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "CreatorId",
                table: "Payrolls",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Payrolls_CreatorId",
                table: "Payrolls",
                column: "CreatorId");

            migrationBuilder.AddForeignKey(
                name: "FK_Payrolls_Employees_CreatorId",
                table: "Payrolls",
                column: "CreatorId",
                principalTable: "Employees",
                principalColumn: "EmployeeId",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Payrolls_Employees_CreatorId",
                table: "Payrolls");

            migrationBuilder.DropIndex(
                name: "IX_Payrolls_CreatorId",
                table: "Payrolls");

            migrationBuilder.DropColumn(
                name: "CreatorId",
                table: "Payrolls");
        }
    }
}
