﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.EntityFrameworkCore.Metadata;

namespace DocumentManagement.Data.Migrations
{
    public partial class AddedLeaveApplicationEntity : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<DateTime>(
                name: "Date",
                table: "Vouchers",
                type: "date",
                nullable: false,
                oldClrType: typeof(DateTime),
                oldType: "Date");

            migrationBuilder.CreateTable(
                name: "LeaveApplications",
                columns: table => new
                {
                    LeaveApplicationId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    ApplicantId = table.Column<string>(nullable: true),
                    Count = table.Column<int>(nullable: false, computedColumnSql: "DATEDIFF(day, [Till], [From])"),
                    Document = table.Column<byte[]>(nullable: true),
                    DocumentTitle = table.Column<string>(nullable: true),
                    From = table.Column<DateTime>(type: "date", nullable: false),
                    LeavePeriod = table.Column<string>(nullable: true),
                    LeaveType = table.Column<int>(nullable: false),
                    Reason = table.Column<string>(nullable: true),
                    Status = table.Column<int>(nullable: false),
                    Till = table.Column<DateTime>(type: "date", nullable: false),
                    Timestamp = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LeaveApplications", x => x.LeaveApplicationId);
                    table.ForeignKey(
                        name: "FK_LeaveApplications_Employees_ApplicantId",
                        column: x => x.ApplicantId,
                        principalTable: "Employees",
                        principalColumn: "EmployeeId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_LeaveApplications_ApplicantId",
                table: "LeaveApplications",
                column: "ApplicantId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "LeaveApplications");

            migrationBuilder.AlterColumn<DateTime>(
                name: "Date",
                table: "Vouchers",
                type: "Date",
                nullable: false,
                oldClrType: typeof(DateTime),
                oldType: "date");
        }
    }
}
