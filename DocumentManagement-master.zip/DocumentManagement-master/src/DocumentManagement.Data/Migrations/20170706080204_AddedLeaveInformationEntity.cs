﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.EntityFrameworkCore.Metadata;

namespace DocumentManagement.Data.Migrations
{
    public partial class AddedLeaveInformationEntity : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_AcademicInformations_Employees_EmployeeId",
                table: "AcademicInformations");

            migrationBuilder.DropForeignKey(
                name: "FK_PersonalInformations_Addresses_AddressSerial",
                table: "PersonalInformations");

            migrationBuilder.DropForeignKey(
                name: "FK_PersonalInformations_Employees_EmployeeId",
                table: "PersonalInformations");

            migrationBuilder.DropForeignKey(
                name: "FK_TrainingInformations_Employees_EmployeeId",
                table: "TrainingInformations");

            migrationBuilder.DropPrimaryKey(
                name: "PK_TrainingInformations",
                table: "TrainingInformations");

            migrationBuilder.DropPrimaryKey(
                name: "PK_PersonalInformations",
                table: "PersonalInformations");

            migrationBuilder.DropPrimaryKey(
                name: "PK_AcademicInformations",
                table: "AcademicInformations");

            migrationBuilder.RenameTable(
                name: "TrainingInformations",
                newName: "TrainingInformation");

            migrationBuilder.RenameTable(
                name: "PersonalInformations",
                newName: "PersonalInformation");

            migrationBuilder.RenameTable(
                name: "AcademicInformations",
                newName: "AcademicInformation");

            migrationBuilder.RenameIndex(
                name: "IX_TrainingInformations_EmployeeId",
                table: "TrainingInformation",
                newName: "IX_TrainingInformation_EmployeeId");

            migrationBuilder.RenameIndex(
                name: "IX_PersonalInformations_EmployeeId",
                table: "PersonalInformation",
                newName: "IX_PersonalInformation_EmployeeId");

            migrationBuilder.RenameIndex(
                name: "IX_PersonalInformations_AddressSerial",
                table: "PersonalInformation",
                newName: "IX_PersonalInformation_AddressSerial");

            migrationBuilder.RenameIndex(
                name: "IX_AcademicInformations_EmployeeId",
                table: "AcademicInformation",
                newName: "IX_AcademicInformation_EmployeeId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_TrainingInformation",
                table: "TrainingInformation",
                column: "Serial");

            migrationBuilder.AddPrimaryKey(
                name: "PK_PersonalInformation",
                table: "PersonalInformation",
                column: "Serial");

            migrationBuilder.AddPrimaryKey(
                name: "PK_AcademicInformation",
                table: "AcademicInformation",
                column: "Serial");

            migrationBuilder.CreateTable(
                name: "LeaveInformation",
                columns: table => new
                {
                    LeaveInformationId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    EmployeeId = table.Column<string>(nullable: true),
                    OtherLeave = table.Column<int>(nullable: false),
                    SickLeave = table.Column<int>(nullable: false),
                    Vacation = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LeaveInformation", x => x.LeaveInformationId);
                    table.ForeignKey(
                        name: "FK_LeaveInformation_Employees_EmployeeId",
                        column: x => x.EmployeeId,
                        principalTable: "Employees",
                        principalColumn: "EmployeeId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_LeaveInformation_EmployeeId",
                table: "LeaveInformation",
                column: "EmployeeId",
                unique: true);

            migrationBuilder.AddForeignKey(
                name: "FK_AcademicInformation_Employees_EmployeeId",
                table: "AcademicInformation",
                column: "EmployeeId",
                principalTable: "Employees",
                principalColumn: "EmployeeId",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_PersonalInformation_Addresses_AddressSerial",
                table: "PersonalInformation",
                column: "AddressSerial",
                principalTable: "Addresses",
                principalColumn: "Serial",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_PersonalInformation_Employees_EmployeeId",
                table: "PersonalInformation",
                column: "EmployeeId",
                principalTable: "Employees",
                principalColumn: "EmployeeId",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_TrainingInformation_Employees_EmployeeId",
                table: "TrainingInformation",
                column: "EmployeeId",
                principalTable: "Employees",
                principalColumn: "EmployeeId",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_AcademicInformation_Employees_EmployeeId",
                table: "AcademicInformation");

            migrationBuilder.DropForeignKey(
                name: "FK_PersonalInformation_Addresses_AddressSerial",
                table: "PersonalInformation");

            migrationBuilder.DropForeignKey(
                name: "FK_PersonalInformation_Employees_EmployeeId",
                table: "PersonalInformation");

            migrationBuilder.DropForeignKey(
                name: "FK_TrainingInformation_Employees_EmployeeId",
                table: "TrainingInformation");

            migrationBuilder.DropTable(
                name: "LeaveInformation");

            migrationBuilder.DropPrimaryKey(
                name: "PK_TrainingInformation",
                table: "TrainingInformation");

            migrationBuilder.DropPrimaryKey(
                name: "PK_PersonalInformation",
                table: "PersonalInformation");

            migrationBuilder.DropPrimaryKey(
                name: "PK_AcademicInformation",
                table: "AcademicInformation");

            migrationBuilder.RenameTable(
                name: "TrainingInformation",
                newName: "TrainingInformations");

            migrationBuilder.RenameTable(
                name: "PersonalInformation",
                newName: "PersonalInformations");

            migrationBuilder.RenameTable(
                name: "AcademicInformation",
                newName: "AcademicInformations");

            migrationBuilder.RenameIndex(
                name: "IX_TrainingInformation_EmployeeId",
                table: "TrainingInformations",
                newName: "IX_TrainingInformations_EmployeeId");

            migrationBuilder.RenameIndex(
                name: "IX_PersonalInformation_EmployeeId",
                table: "PersonalInformations",
                newName: "IX_PersonalInformations_EmployeeId");

            migrationBuilder.RenameIndex(
                name: "IX_PersonalInformation_AddressSerial",
                table: "PersonalInformations",
                newName: "IX_PersonalInformations_AddressSerial");

            migrationBuilder.RenameIndex(
                name: "IX_AcademicInformation_EmployeeId",
                table: "AcademicInformations",
                newName: "IX_AcademicInformations_EmployeeId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_TrainingInformations",
                table: "TrainingInformations",
                column: "Serial");

            migrationBuilder.AddPrimaryKey(
                name: "PK_PersonalInformations",
                table: "PersonalInformations",
                column: "Serial");

            migrationBuilder.AddPrimaryKey(
                name: "PK_AcademicInformations",
                table: "AcademicInformations",
                column: "Serial");

            migrationBuilder.AddForeignKey(
                name: "FK_AcademicInformations_Employees_EmployeeId",
                table: "AcademicInformations",
                column: "EmployeeId",
                principalTable: "Employees",
                principalColumn: "EmployeeId",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_PersonalInformations_Addresses_AddressSerial",
                table: "PersonalInformations",
                column: "AddressSerial",
                principalTable: "Addresses",
                principalColumn: "Serial",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_PersonalInformations_Employees_EmployeeId",
                table: "PersonalInformations",
                column: "EmployeeId",
                principalTable: "Employees",
                principalColumn: "EmployeeId",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_TrainingInformations_Employees_EmployeeId",
                table: "TrainingInformations",
                column: "EmployeeId",
                principalTable: "Employees",
                principalColumn: "EmployeeId",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
