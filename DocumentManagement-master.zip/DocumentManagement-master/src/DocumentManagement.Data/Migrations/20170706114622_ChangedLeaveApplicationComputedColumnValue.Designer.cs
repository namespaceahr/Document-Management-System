﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using DocumentManagement.Data.Models;
using DocumentManagement.Data.Enums;

namespace DocumentManagement.Data.Migrations
{
    [DbContext(typeof(DocumentContext))]
    [Migration("20170706114622_ChangedLeaveApplicationComputedColumnValue")]
    partial class ChangedLeaveApplicationComputedColumnValue
    {
        protected override void BuildTargetModel(ModelBuilder modelBuilder)
        {
            modelBuilder
                .HasAnnotation("ProductVersion", "1.1.2")
                .HasAnnotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn);

            modelBuilder.Entity("DocumentManagement.Data.Models.AcademicInformation", b =>
                {
                    b.Property<int>("Serial")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("EmployeeId");

                    b.Property<string>("Exam");

                    b.Property<string>("Group");

                    b.Property<string>("Institute");

                    b.Property<int>("PassingYear");

                    b.Property<string>("Result");

                    b.HasKey("Serial");

                    b.HasIndex("EmployeeId");

                    b.ToTable("AcademicInformation");
                });

            modelBuilder.Entity("DocumentManagement.Data.Models.Address", b =>
                {
                    b.Property<int>("Serial")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("Country");

                    b.Property<string>("District");

                    b.Property<string>("Division");

                    b.Property<string>("EmployeeId");

                    b.Property<string>("House");

                    b.Property<string>("Street");

                    b.Property<string>("Thana");

                    b.HasKey("Serial");

                    b.HasIndex("EmployeeId");

                    b.ToTable("Addresses");
                });

            modelBuilder.Entity("DocumentManagement.Data.Models.AssignedOperation", b =>
                {
                    b.Property<int>("AssignedOperationId")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("EmployeeId");

                    b.Property<int>("ModuleOperationId");

                    b.HasKey("AssignedOperationId");

                    b.HasIndex("EmployeeId");

                    b.HasIndex("ModuleOperationId");

                    b.ToTable("AssignedOperations");
                });

            modelBuilder.Entity("DocumentManagement.Data.Models.Attendance", b =>
                {
                    b.Property<int>("AttendanceId")
                        .ValueGeneratedOnAdd();

                    b.Property<int>("AttendanceStatus");

                    b.Property<DateTime?>("CheckIn")
                        .HasColumnType("Time");

                    b.Property<DateTime?>("CheckOut")
                        .HasColumnType("Time");

                    b.Property<DateTime>("Date")
                        .HasColumnType("Date");

                    b.Property<string>("EmployeeId");

                    b.HasKey("AttendanceId");

                    b.HasIndex("EmployeeId");

                    b.ToTable("Attendances");
                });

            modelBuilder.Entity("DocumentManagement.Data.Models.Department", b =>
                {
                    b.Property<int>("DepartmentId")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("DepartmentName");

                    b.HasKey("DepartmentId");

                    b.ToTable("Departments");
                });

            modelBuilder.Entity("DocumentManagement.Data.Models.Designation", b =>
                {
                    b.Property<int>("DesignationId")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("DesignationName");

                    b.HasKey("DesignationId");

                    b.ToTable("Designations");
                });

            modelBuilder.Entity("DocumentManagement.Data.Models.Document", b =>
                {
                    b.Property<int>("DocumentId")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("Category");

                    b.Property<string>("Description");

                    b.Property<string>("EmployeeId");

                    b.Property<string>("File");

                    b.Property<byte[]>("FileData");

                    b.Property<string>("Note");

                    b.Property<int>("Status");

                    b.Property<DateTime>("Timestamp");

                    b.Property<string>("Title");

                    b.HasKey("DocumentId");

                    b.HasIndex("EmployeeId");

                    b.ToTable("Documents");
                });

            modelBuilder.Entity("DocumentManagement.Data.Models.Employee", b =>
                {
                    b.Property<string>("EmployeeId")
                        .ValueGeneratedOnAdd();

                    b.Property<bool>("Active")
                        .ValueGeneratedOnAdd()
                        .HasDefaultValue(true);

                    b.Property<int>("DepartmentId");

                    b.Property<int>("DesignationId");

                    b.Property<DateTime>("JoiningDate")
                        .HasColumnType("Date");

                    b.Property<int>("SalaryGradeId");

                    b.HasKey("EmployeeId");

                    b.HasIndex("DepartmentId");

                    b.HasIndex("DesignationId");

                    b.HasIndex("SalaryGradeId");

                    b.ToTable("Employees");
                });

            modelBuilder.Entity("DocumentManagement.Data.Models.LeaveApplication", b =>
                {
                    b.Property<int>("LeaveApplicationId")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("ApplicantId");

                    b.Property<int>("Count")
                        .ValueGeneratedOnAddOrUpdate()
                        .HasComputedColumnSql("DATEDIFF(day, [From], [Till]) + 1");

                    b.Property<byte[]>("Document");

                    b.Property<string>("DocumentTitle");

                    b.Property<DateTime>("From")
                        .HasColumnType("date");

                    b.Property<string>("LeavePeriod");

                    b.Property<int>("LeaveType");

                    b.Property<string>("Reason");

                    b.Property<int>("Status");

                    b.Property<DateTime>("Till")
                        .HasColumnType("date");

                    b.Property<DateTime>("Timestamp");

                    b.HasKey("LeaveApplicationId");

                    b.HasIndex("ApplicantId");

                    b.ToTable("LeaveApplications");
                });

            modelBuilder.Entity("DocumentManagement.Data.Models.LeaveInformation", b =>
                {
                    b.Property<int>("LeaveInformationId")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("EmployeeId");

                    b.Property<int>("OtherLeave");

                    b.Property<int>("SickLeave");

                    b.Property<int>("Vacation");

                    b.HasKey("LeaveInformationId");

                    b.HasIndex("EmployeeId")
                        .IsUnique();

                    b.ToTable("LeaveInformation");
                });

            modelBuilder.Entity("DocumentManagement.Data.Models.MetaTag", b =>
                {
                    b.Property<int>("DocumentId");

                    b.Property<string>("Tag");

                    b.HasKey("DocumentId", "Tag");

                    b.ToTable("MetaTags");
                });

            modelBuilder.Entity("DocumentManagement.Data.Models.Module", b =>
                {
                    b.Property<int>("ModuleId")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("ModuleName");

                    b.HasKey("ModuleId");

                    b.ToTable("Modules");
                });

            modelBuilder.Entity("DocumentManagement.Data.Models.ModuleOperation", b =>
                {
                    b.Property<int>("ModuleOperationId")
                        .ValueGeneratedOnAdd();

                    b.Property<int>("ModuleId");

                    b.Property<string>("Operation");

                    b.Property<string>("Routes");

                    b.HasKey("ModuleOperationId");

                    b.HasIndex("ModuleId");

                    b.ToTable("ModuleOperations");
                });

            modelBuilder.Entity("DocumentManagement.Data.Models.Payroll", b =>
                {
                    b.Property<int>("PayrollId")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("AccountNo");

                    b.Property<decimal>("BasicSalary");

                    b.Property<DateTime>("CreatedAt");

                    b.Property<string>("CreatorId");

                    b.Property<DateTime>("DisbursementDate");

                    b.Property<string>("EmployeeId");

                    b.Property<decimal>("HouseRent");

                    b.Property<decimal>("IncomeTax");

                    b.Property<decimal>("MedicalAllowance");

                    b.Property<int>("Month");

                    b.Property<string>("Others");

                    b.Property<decimal>("ProvidentFund");

                    b.Property<decimal>("Transportation");

                    b.Property<decimal>("UnpaidLeave");

                    b.Property<int>("Year");

                    b.HasKey("PayrollId");

                    b.HasIndex("CreatorId");

                    b.HasIndex("EmployeeId");

                    b.ToTable("Payrolls");
                });

            modelBuilder.Entity("DocumentManagement.Data.Models.PersonalInformation", b =>
                {
                    b.Property<int>("Serial")
                        .ValueGeneratedOnAdd();

                    b.Property<int?>("AddressSerial");

                    b.Property<DateTime>("BirthDate")
                        .HasColumnType("Date");

                    b.Property<string>("Email");

                    b.Property<string>("EmployeeId");

                    b.Property<string>("FatherName");

                    b.Property<string>("FirstName");

                    b.Property<int>("Gender");

                    b.Property<string>("LastName");

                    b.Property<int>("MaritalStatus");

                    b.Property<string>("MotherName");

                    b.Property<string>("NationalId");

                    b.Property<string>("Phone");

                    b.Property<int>("Religion");

                    b.HasKey("Serial");

                    b.HasIndex("AddressSerial");

                    b.HasIndex("EmployeeId")
                        .IsUnique();

                    b.ToTable("PersonalInformation");
                });

            modelBuilder.Entity("DocumentManagement.Data.Models.Receipt", b =>
                {
                    b.Property<int>("ReceiptId")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("CreatorId");

                    b.Property<DateTime>("Date")
                        .HasColumnType("Date");

                    b.Property<string>("Description");

                    b.Property<string>("Items");

                    b.Property<string>("Note");

                    b.Property<string>("Organization");

                    b.Property<string>("PaymentInformation");

                    b.Property<int>("PaymentType");

                    b.Property<string>("ProcurerId");

                    b.Property<int>("ReceiptNo");

                    b.Property<int>("Status");

                    b.HasKey("ReceiptId");

                    b.HasIndex("CreatorId");

                    b.HasIndex("ProcurerId");

                    b.ToTable("Receipts");
                });

            modelBuilder.Entity("DocumentManagement.Data.Models.Reference", b =>
                {
                    b.Property<int>("Serial")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("Designation");

                    b.Property<string>("Email");

                    b.Property<string>("EmployeeId");

                    b.Property<string>("Organization");

                    b.Property<string>("Phone");

                    b.Property<string>("Referee");

                    b.HasKey("Serial");

                    b.HasIndex("EmployeeId");

                    b.ToTable("References");
                });

            modelBuilder.Entity("DocumentManagement.Data.Models.SalaryGrade", b =>
                {
                    b.Property<int>("SalaryGradeId")
                        .ValueGeneratedOnAdd();

                    b.Property<decimal>("BasicSalary");

                    b.Property<string>("GradeName");

                    b.Property<decimal>("HouseRent");

                    b.Property<int?>("IncrementDuration");

                    b.Property<double?>("IncrementRate");

                    b.Property<DateTime>("LastUpdated")
                        .ValueGeneratedOnAddOrUpdate();

                    b.Property<decimal>("MedicalAllowance");

                    b.Property<string>("Others");

                    b.Property<decimal>("Transportation");

                    b.HasKey("SalaryGradeId");

                    b.ToTable("SalaryGrades");
                });

            modelBuilder.Entity("DocumentManagement.Data.Models.TrainingInformation", b =>
                {
                    b.Property<int>("Serial")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("Achievement");

                    b.Property<string>("EmployeeId");

                    b.Property<DateTime>("EndDate")
                        .HasColumnType("Date");

                    b.Property<string>("Organization");

                    b.Property<DateTime>("StartDate")
                        .HasColumnType("Date");

                    b.Property<string>("Training");

                    b.HasKey("Serial");

                    b.HasIndex("EmployeeId");

                    b.ToTable("TrainingInformation");
                });

            modelBuilder.Entity("DocumentManagement.Data.Models.Transaction", b =>
                {
                    b.Property<int>("TransactionId")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("EmployeeId");

                    b.Property<int?>("LogId");

                    b.Property<string>("MacAddress");

                    b.Property<string>("RowId");

                    b.Property<int>("Tablespace");

                    b.Property<DateTime>("Timestamp");

                    b.Property<int>("TransactionType");

                    b.HasKey("TransactionId");

                    b.HasIndex("EmployeeId");

                    b.ToTable("Transactions");
                });

            modelBuilder.Entity("DocumentManagement.Data.Models.Voucher", b =>
                {
                    b.Property<int>("VoucherId")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("CreatorId");

                    b.Property<DateTime>("Date")
                        .HasColumnType("date");

                    b.Property<int>("DepartmentId");

                    b.Property<string>("Description");

                    b.Property<string>("Items");

                    b.Property<string>("Note");

                    b.Property<string>("Organization");

                    b.Property<string>("ProcurerId");

                    b.Property<int>("Status");

                    b.Property<int>("VoucherNo");

                    b.HasKey("VoucherId");

                    b.HasIndex("CreatorId");

                    b.HasIndex("DepartmentId");

                    b.HasIndex("ProcurerId");

                    b.ToTable("Vouchers");
                });

            modelBuilder.Entity("DocumentManagement.Data.Models.WorkExperience", b =>
                {
                    b.Property<int>("Serial")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("EmployeeId");

                    b.Property<string>("JobTitle");

                    b.Property<DateTime>("JoiningDate");

                    b.Property<string>("Organization");

                    b.Property<DateTime>("ReleaseDate");

                    b.Property<string>("Roles");

                    b.HasKey("Serial");

                    b.HasIndex("EmployeeId");

                    b.ToTable("WorkExperiences");
                });

            modelBuilder.Entity("DocumentManagement.Data.Models.AcademicInformation", b =>
                {
                    b.HasOne("DocumentManagement.Data.Models.Employee", "Employee")
                        .WithMany("AcademicInformations")
                        .HasForeignKey("EmployeeId");
                });

            modelBuilder.Entity("DocumentManagement.Data.Models.Address", b =>
                {
                    b.HasOne("DocumentManagement.Data.Models.Employee", "Employee")
                        .WithMany()
                        .HasForeignKey("EmployeeId");
                });

            modelBuilder.Entity("DocumentManagement.Data.Models.AssignedOperation", b =>
                {
                    b.HasOne("DocumentManagement.Data.Models.Employee", "Employee")
                        .WithMany("AssignedOperations")
                        .HasForeignKey("EmployeeId");

                    b.HasOne("DocumentManagement.Data.Models.ModuleOperation", "ModuleOperation")
                        .WithMany("AssignedOperations")
                        .HasForeignKey("ModuleOperationId")
                        .OnDelete(DeleteBehavior.Cascade);
                });

            modelBuilder.Entity("DocumentManagement.Data.Models.Attendance", b =>
                {
                    b.HasOne("DocumentManagement.Data.Models.Employee", "Employee")
                        .WithMany("Attendances")
                        .HasForeignKey("EmployeeId");
                });

            modelBuilder.Entity("DocumentManagement.Data.Models.Document", b =>
                {
                    b.HasOne("DocumentManagement.Data.Models.Employee", "Employee")
                        .WithMany()
                        .HasForeignKey("EmployeeId");
                });

            modelBuilder.Entity("DocumentManagement.Data.Models.Employee", b =>
                {
                    b.HasOne("DocumentManagement.Data.Models.Department", "Department")
                        .WithMany("Employees")
                        .HasForeignKey("DepartmentId")
                        .OnDelete(DeleteBehavior.Cascade);

                    b.HasOne("DocumentManagement.Data.Models.Designation", "Designation")
                        .WithMany("Employees")
                        .HasForeignKey("DesignationId")
                        .OnDelete(DeleteBehavior.Cascade);

                    b.HasOne("DocumentManagement.Data.Models.SalaryGrade", "SalaryGrade")
                        .WithMany("Employees")
                        .HasForeignKey("SalaryGradeId")
                        .OnDelete(DeleteBehavior.Cascade);
                });

            modelBuilder.Entity("DocumentManagement.Data.Models.LeaveApplication", b =>
                {
                    b.HasOne("DocumentManagement.Data.Models.Employee", "Applicant")
                        .WithMany("LeaveApplications")
                        .HasForeignKey("ApplicantId");
                });

            modelBuilder.Entity("DocumentManagement.Data.Models.LeaveInformation", b =>
                {
                    b.HasOne("DocumentManagement.Data.Models.Employee", "Employee")
                        .WithOne("LeaveInformation")
                        .HasForeignKey("DocumentManagement.Data.Models.LeaveInformation", "EmployeeId");
                });

            modelBuilder.Entity("DocumentManagement.Data.Models.MetaTag", b =>
                {
                    b.HasOne("DocumentManagement.Data.Models.Document", "Document")
                        .WithMany("MetaTags")
                        .HasForeignKey("DocumentId")
                        .OnDelete(DeleteBehavior.Cascade);
                });

            modelBuilder.Entity("DocumentManagement.Data.Models.ModuleOperation", b =>
                {
                    b.HasOne("DocumentManagement.Data.Models.Module", "Module")
                        .WithMany("ModuleOperations")
                        .HasForeignKey("ModuleId")
                        .OnDelete(DeleteBehavior.Cascade);
                });

            modelBuilder.Entity("DocumentManagement.Data.Models.Payroll", b =>
                {
                    b.HasOne("DocumentManagement.Data.Models.Employee", "Creator")
                        .WithMany()
                        .HasForeignKey("CreatorId");

                    b.HasOne("DocumentManagement.Data.Models.Employee", "Employee")
                        .WithMany("Payrolls")
                        .HasForeignKey("EmployeeId");
                });

            modelBuilder.Entity("DocumentManagement.Data.Models.PersonalInformation", b =>
                {
                    b.HasOne("DocumentManagement.Data.Models.Address", "Address")
                        .WithMany()
                        .HasForeignKey("AddressSerial");

                    b.HasOne("DocumentManagement.Data.Models.Employee", "Employee")
                        .WithOne("PersonalInformation")
                        .HasForeignKey("DocumentManagement.Data.Models.PersonalInformation", "EmployeeId");
                });

            modelBuilder.Entity("DocumentManagement.Data.Models.Receipt", b =>
                {
                    b.HasOne("DocumentManagement.Data.Models.Employee", "Creator")
                        .WithMany()
                        .HasForeignKey("CreatorId");

                    b.HasOne("DocumentManagement.Data.Models.Employee", "Procurer")
                        .WithMany()
                        .HasForeignKey("ProcurerId");
                });

            modelBuilder.Entity("DocumentManagement.Data.Models.Reference", b =>
                {
                    b.HasOne("DocumentManagement.Data.Models.Employee", "Employee")
                        .WithMany("References")
                        .HasForeignKey("EmployeeId");
                });

            modelBuilder.Entity("DocumentManagement.Data.Models.TrainingInformation", b =>
                {
                    b.HasOne("DocumentManagement.Data.Models.Employee", "Employee")
                        .WithMany("TrainingInformations")
                        .HasForeignKey("EmployeeId");
                });

            modelBuilder.Entity("DocumentManagement.Data.Models.Transaction", b =>
                {
                    b.HasOne("DocumentManagement.Data.Models.Employee", "Employee")
                        .WithMany("Transactions")
                        .HasForeignKey("EmployeeId");
                });

            modelBuilder.Entity("DocumentManagement.Data.Models.Voucher", b =>
                {
                    b.HasOne("DocumentManagement.Data.Models.Employee", "Creator")
                        .WithMany()
                        .HasForeignKey("CreatorId");

                    b.HasOne("DocumentManagement.Data.Models.Department", "Department")
                        .WithMany()
                        .HasForeignKey("DepartmentId")
                        .OnDelete(DeleteBehavior.Cascade);

                    b.HasOne("DocumentManagement.Data.Models.Employee", "Procurer")
                        .WithMany()
                        .HasForeignKey("ProcurerId");
                });

            modelBuilder.Entity("DocumentManagement.Data.Models.WorkExperience", b =>
                {
                    b.HasOne("DocumentManagement.Data.Models.Employee", "Employee")
                        .WithMany("WorkExperiences")
                        .HasForeignKey("EmployeeId");
                });
        }
    }
}
