﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore.Migrations;

namespace DocumentManagement.Data.Migrations
{
    public partial class ChangedLeaveApplicationComputedColumnValue : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<int>(
                name: "Count",
                table: "LeaveApplications",
                nullable: false,
                computedColumnSql: "DATEDIFF(day, [From], [Till]) + 1",
                oldClrType: typeof(int),
                oldComputedColumnSql: "DATEDIFF(day, [Till], [From])");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<int>(
                name: "Count",
                table: "LeaveApplications",
                nullable: false,
                computedColumnSql: "DATEDIFF(day, [Till], [From])",
                oldClrType: typeof(int),
                oldComputedColumnSql: "DATEDIFF(day, [From], [Till]) + 1");
        }
    }
}
