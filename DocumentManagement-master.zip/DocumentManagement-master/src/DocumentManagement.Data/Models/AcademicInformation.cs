﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DocumentManagement.Data.Models
{
    public class AcademicInformation
    {
        public int Serial { get; set; }

        public string Exam { get; set; }
        public string Group { get; set; }
        public string Institute { get; set; }
        public string Result { get; set; }
        public int PassingYear { get; set; }

        public string EmployeeId { get; set; }
        public Employee Employee { get; set; }
    }
}
