﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DocumentManagement.Data.Models
{
    public class Address
    {
        public int Serial { get; set; }

        public string House { get; set; }
        public string Street { get; set; }
        public string Thana { get; set; }
        public string District { get; set; }
        public string Division { get; set; }
        public string Country { get; set; }

        public string EmployeeId { get; set; }
        public Employee Employee { get; set; }
    }
}
