﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DocumentManagement.Data.Models
{
    public class AssignedOperation
    {
        public int AssignedOperationId { get; set; }

        public string EmployeeId { get; set; }
        public Employee Employee { get; set; }
        public int ModuleOperationId { get; set; }
        public ModuleOperation ModuleOperation { get; set; }
    }
}
