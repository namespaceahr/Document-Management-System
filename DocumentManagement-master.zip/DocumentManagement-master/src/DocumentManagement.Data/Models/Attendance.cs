﻿using DocumentManagement.Data.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace DocumentManagement.Data.Models
{
    public class Attendance
    {
        public int AttendanceId { get; set; }
        public DateTime Date { get; set; }
        public DateTime? CheckIn { get; set; }
        public DateTime? CheckOut { get; set; }
        public AttendanceStatus AttendanceStatus { get; set; }

        public string EmployeeId { get; set; }
        public Employee Employee { get; set; }
    }
}
