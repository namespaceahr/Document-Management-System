﻿using DocumentManagement.Data.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DocumentManagement.Data.Models
{
    public class Document
    {
        public int DocumentId { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string Category { get; set; }
        public string File { get; set; }
        public byte[] FileData { get; set; }
        public DateTime Timestamp { get; set; }
        public ApprovalStatus Status { get; set; }
        public string Note { get; set; }

        public string EmployeeId { get; set; }
        public Employee Employee { get; set; }
        public List<MetaTag> MetaTags { get; set; }
    }
}
