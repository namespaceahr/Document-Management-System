﻿using Microsoft.EntityFrameworkCore;
using System;

namespace DocumentManagement.Data.Models
{
    public class DocumentContext : DbContext
    {
        public DbSet<Document> Documents { get; set; }
        public DbSet<MetaTag> MetaTags { get; set; }
        public DbSet<Transaction> Transactions { get; set; }

        public DbSet<Department> Departments { get; set; }
        public DbSet<Designation> Designations { get; set; }
        public DbSet<SalaryGrade> SalaryGrades { get; set; }
        public DbSet<Employee> Employees { get; set; }
        public DbSet<Attendance> Attendances { get; set; }
        public DbSet<LeaveInformation> LeaveInformation { get; set; }
        public DbSet<LeaveApplication> LeaveApplications { get; set; }
        public DbSet<Payroll> Payrolls { get; set; }

        public DbSet<PersonalInformation> PersonalInformation { get; set; }
        public DbSet<AcademicInformation> AcademicInformation { get; set; }
        public DbSet<TrainingInformation> TrainingInformation { get; set; }
        public DbSet<WorkExperience> WorkExperiences { get; set; }
        public DbSet<Reference> References { get; set; }
        public DbSet<Address> Addresses { get; set; }

        public DbSet<Module> Modules { get; set; }
        public DbSet<ModuleOperation> ModuleOperations { get; set; }
        public DbSet<AssignedOperation> AssignedOperations { get; set; }

        public DbSet<Receipt> Receipts { get; set; }
        public DbSet<Voucher> Vouchers { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            string connectionString = "Data Source=document.database.windows.net;Initial Catalog=documentdb;User ID=docadmin;Password=ubsBDdev$";
            //string connectionString = @"Data Source=(localdb)\mssqllocaldb;Initial Catalog=documentdb;Integrated Security=True";
            optionsBuilder.UseSqlServer(connectionString);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Employee>()
                .HasOne(e => e.PersonalInformation)
                .WithOne(p => p.Employee)
                .HasForeignKey<PersonalInformation>(p => p.EmployeeId);

            modelBuilder.Entity<AcademicInformation>()
                .HasOne(a => a.Employee)
                .WithMany(e => e.AcademicInformations)
                .HasForeignKey(a => a.EmployeeId);

            modelBuilder.Entity<TrainingInformation>()
                .HasOne(t => t.Employee)
                .WithMany(e => e.TrainingInformations)
                .HasForeignKey(t => t.EmployeeId);

            modelBuilder.Entity<WorkExperience>()
                .HasOne(a => a.Employee)
                .WithMany(e => e.WorkExperiences)
                .HasForeignKey(a => a.EmployeeId);

            modelBuilder.Entity<Transaction>()
                .HasOne(a => a.Employee)
                .WithMany(e => e.Transactions)
                .HasForeignKey(a => a.EmployeeId);

            modelBuilder.Entity<Department>()
                .HasMany(d => d.Employees)
                .WithOne(e => e.Department)
                .HasForeignKey(e => e.DepartmentId);

            modelBuilder.Entity<Designation>()
                .HasMany(d => d.Employees)
                .WithOne(e => e.Designation)
                .HasForeignKey(d => d.DesignationId);

            modelBuilder.Entity<SalaryGrade>()
                .HasMany(d => d.Employees)
                .WithOne(e => e.SalaryGrade)
                .HasForeignKey(e => e.SalaryGradeId);

            modelBuilder.Entity<MetaTag>()
                .HasOne(m => m.Document)
                .WithMany(d => d.MetaTags)
                .HasForeignKey(m => m.DocumentId);

            modelBuilder.Entity<Reference>()
                .HasOne(r => r.Employee)
                .WithMany(e => e.References)
                .HasForeignKey(r => r.EmployeeId);

            modelBuilder.Entity<Attendance>()
                .HasOne(a => a.Employee)
                .WithMany(e => e.Attendances)
                .HasForeignKey(a => a.EmployeeId);

            modelBuilder.Entity<ModuleOperation>()
                .HasOne(op => op.Module)
                .WithMany(m => m.ModuleOperations)
                .HasForeignKey(op => op.ModuleId);

            modelBuilder.Entity<AssignedOperation>()
                .HasOne(h => h.ModuleOperation)
                .WithMany(op => op.AssignedOperations)
                .HasForeignKey(h => h.ModuleOperationId);

            modelBuilder.Entity<AssignedOperation>()
                .HasOne(h => h.Employee)
                .WithMany(e => e.AssignedOperations)
                .HasForeignKey(h => h.EmployeeId);

            modelBuilder.Entity<Receipt>(receipt =>
            {
                receipt.HasOne(r => r.Procurer)
                    .WithMany()
                    .HasForeignKey(r => r.ProcurerId);

                receipt.HasOne(r => r.Creator)
                    .WithMany()
                    .HasForeignKey(r => r.CreatorId);

                receipt.Property(r => r.Date)
                    .HasColumnType("Date");
            });

            modelBuilder.Entity<Voucher>(voucher =>
            {
                voucher.HasOne(v => v.Department)
                    .WithMany()
                    .HasForeignKey(v => v.DepartmentId);

                voucher.HasOne(v => v.Procurer)
                    .WithMany()
                    .HasForeignKey(v => v.ProcurerId);

                voucher.HasOne(r => r.Creator)
                    .WithMany()
                    .HasForeignKey(r => r.CreatorId);

                voucher.Property(v => v.Date)
                    .HasColumnType("date");
            });

            modelBuilder.Entity<Payroll>(payroll =>
            {
                payroll.HasOne(p => p.Employee)
                    .WithMany(e => e.Payrolls)
                    .HasForeignKey(p => p.EmployeeId);

                payroll.HasOne(p => p.Creator)
                    .WithMany()
                    .HasForeignKey(p => p.CreatorId);
            });

            modelBuilder.Entity<LeaveApplication>(leaveApplication =>
            {
                leaveApplication.HasOne(l => l.Applicant)
                    .WithMany(e => e.LeaveApplications)
                    .HasForeignKey(l => l.ApplicantId);

                leaveApplication.Property(l => l.Count)
                    .HasComputedColumnSql("DATEDIFF(day, [From], [Till]) + 1");
                leaveApplication.Property(l => l.From)
                    .HasColumnType("date");
                leaveApplication.Property(l => l.Till)
                    .HasColumnType("date");
            });

            modelBuilder.Entity<LeaveInformation>(leaveInformation =>
            {
                leaveInformation.HasOne(l => l.Employee)
                    .WithOne(e => e.LeaveInformation)
                    .HasForeignKey<LeaveInformation>(l => l.EmployeeId);
            });

            //modelBuilder.Entity<Employee>()
            //    .Property(e => e.DepartmentId)
            //    .IsRequired();
            //modelBuilder.Entity<Employee>()
            //    .Property(e => e.SalaryGradeId)
            //    .IsRequired();

            modelBuilder.Entity<AcademicInformation>()
                .HasKey(a => a.Serial);
            modelBuilder.Entity<PersonalInformation>()
                .HasKey(a => a.Serial);
            modelBuilder.Entity<TrainingInformation>()
                .HasKey(t => t.Serial);
            modelBuilder.Entity<WorkExperience>()
                .HasKey(a => a.Serial);
            modelBuilder.Entity<Reference>()
                .HasKey(r => r.Serial);
            modelBuilder.Entity<Address>()
               .HasKey(a => a.Serial);
            modelBuilder.Entity<MetaTag>()
                .HasKey(m => new { m.DocumentId, m.Tag });

            modelBuilder.Entity<Employee>()
                .Property(e => e.JoiningDate)
                .HasColumnType("Date");

            modelBuilder.Entity<TrainingInformation>()
                .Property(t => t.StartDate)
                .HasColumnType("Date");

            modelBuilder.Entity<TrainingInformation>()
                .Property(t => t.EndDate)
                .HasColumnType("Date");

            modelBuilder.Entity<PersonalInformation>()
                .Property(p => p.BirthDate)
                .HasColumnType("Date");

            modelBuilder.Entity<Attendance>()
                .Property(a => a.Date)
                .HasColumnType("Date");

            modelBuilder.Entity<Attendance>()
                .Property(a => a.CheckIn)
                .HasColumnType("Time");

            modelBuilder.Entity<Attendance>()
                .Property(a => a.CheckOut)
                .HasColumnType("Time");

            modelBuilder.Entity<Employee>()
                .Property(e => e.Active)
                .HasDefaultValue(true);

            modelBuilder.Entity<SalaryGrade>()
                .Property(s => s.LastUpdated)
                .ValueGeneratedOnAddOrUpdate();
        }
    }
}
