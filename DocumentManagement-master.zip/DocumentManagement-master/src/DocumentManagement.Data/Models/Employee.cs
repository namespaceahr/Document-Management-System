﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DocumentManagement.Data.Models
{
    public class Employee
    {
        public string EmployeeId { get; set; }
        public DateTime JoiningDate { get; set; }
        public bool Active { get; set; }

        public int DesignationId { get; set; }
        public Designation Designation { get; set; }
        public int DepartmentId { get; set; }
        public Department Department { get; set; }
        public int SalaryGradeId { get; set; }
        public SalaryGrade SalaryGrade { get; set; }

        public PersonalInformation PersonalInformation { get; set; }
        public List<AcademicInformation> AcademicInformations { get; set; }
        public List<TrainingInformation> TrainingInformations { get; set; }
        public List<WorkExperience> WorkExperiences { get; set; }
        public List<Transaction> Transactions { get; set; }
        public List<Reference> References { get; set; }
        public List<Attendance> Attendances { get; set; }
        public LeaveInformation LeaveInformation { get; set; }
        public List<LeaveApplication> LeaveApplications { get; set; }
        public List<Payroll> Payrolls { get; set; }
        public List<AssignedOperation> AssignedOperations { get; set; }
    }
}
