﻿using DocumentManagement.Data.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace DocumentManagement.Data.Models
{
    public class LeaveApplication
    {
        public int LeaveApplicationId { get; set; }
        public LeaveType LeaveType { get; set; }
        public string LeavePeriod { get; set; }
        public DateTime From { get; set; }
        public DateTime Till { get; set; }
        public int Count { get; set; }
        public string Reason { get; set; }
        public string DocumentTitle { get; set; }
        public byte[] Document { get; set; }
        public LeaveStatus Status { get; set; }
        public DateTime Timestamp { get; set; }

        public string ApplicantId { get; set; }
        public Employee Applicant { get; set; }
    }
}
