﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DocumentManagement.Data.Models
{
    public class LeaveInformation
    {
        public int LeaveInformationId { get; set; }
        public int Vacation { get; set; }
        public int SickLeave { get; set; }
        public int OtherLeave { get; set; }

        public string EmployeeId { get; set; }
        public Employee Employee { get; set; }
    }
}
