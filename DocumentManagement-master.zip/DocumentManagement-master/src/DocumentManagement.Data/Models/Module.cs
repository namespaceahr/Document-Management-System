﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DocumentManagement.Data.Models
{
    public class Module
    {
        public int ModuleId { get; set; }
        public string ModuleName { get; set; }

        public List<ModuleOperation> ModuleOperations { get; set; }
    }
}
