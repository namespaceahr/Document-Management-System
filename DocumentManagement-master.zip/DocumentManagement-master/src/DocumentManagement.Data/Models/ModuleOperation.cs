﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DocumentManagement.Data.Models
{
    public class ModuleOperation
    {
        public int ModuleOperationId { get; set; }
        public string Operation { get; set; }
        public string Routes { get; set; } // Dashboard Items
        public int ModuleId { get; set; }
        public Module Module { get; set; }
        public List<AssignedOperation> AssignedOperations { get; set; }
    }
}
