﻿using DocumentManagement.Data.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace DocumentManagement.Data.Models
{
    public class Payroll
    {
        public int PayrollId { get; set; }
        public int Year { get; set; }
        public Month Month { get; set; }

        public decimal BasicSalary { get; set; }
        public decimal MedicalAllowance { get; set; }
        public decimal HouseRent { get; set; }
        public decimal Transportation { get; set; }
        public string Others { get; set; }

        public decimal IncomeTax { get; set; }
        public decimal ProvidentFund { get; set; }
        public decimal UnpaidLeave { get; set; }

        public string AccountNo { get; set; }
        public DateTime DisbursementDate { get; set; }
        public DateTime CreatedAt { get; set; }

        // Employee receiving the salary
        public string EmployeeId { get; set; }
        public Employee Employee { get; set; }
        // Employee creating the payroll
        public string CreatorId { get; set; }
        public Employee Creator { get; set; }
    }
}
