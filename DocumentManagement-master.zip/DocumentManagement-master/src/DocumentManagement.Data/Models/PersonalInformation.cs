﻿using DocumentManagement.Data.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace DocumentManagement.Data.Models
{
    public class PersonalInformation
    {
        public int Serial { get; set; }

        public string NationalId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string FatherName { get; set; }
        public string MotherName { get; set; }
        public DateTime BirthDate { get; set; }
        public Gender Gender { get; set; }
        public Religion Religion { get; set; }
        public MaritalStatus MaritalStatus { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }

        public Address Address { get; set; }

        public string EmployeeId { get; set; }
        public Employee Employee { get; set; }
    }
}
