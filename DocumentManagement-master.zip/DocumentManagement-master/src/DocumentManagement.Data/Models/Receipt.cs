﻿using DocumentManagement.Data.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace DocumentManagement.Data.Models
{
    public class Receipt
    {
        public int ReceiptId { get; set; }
        public int ReceiptNo { get; set; }
        public DateTime Date { get; set; }
        public string Description { get; set; }
        public string Organization { get; set; }
        public string Items { get; set; }
        public PaymentType PaymentType { get; set; }
        public string PaymentInformation { get; set; }
        public ApprovalStatus Status { get; set; }
        public string Note { get; set; }

        public string ProcurerId { get; set; }
        public Employee Procurer { get; set; }
        public string CreatorId { get; set; }
        public Employee Creator { get; set; }
    }
}
