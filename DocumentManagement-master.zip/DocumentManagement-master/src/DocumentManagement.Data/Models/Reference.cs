﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DocumentManagement.Data.Models
{
    public class Reference
    {
        public int Serial { get; set; }

        public string Referee { get; set; }
        public string Designation { get; set; }
        public string Organization { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }

        public string EmployeeId { get; set; }
        public Employee Employee { get; set; }
    }
}
