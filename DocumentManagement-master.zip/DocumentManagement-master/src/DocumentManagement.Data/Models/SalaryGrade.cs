﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DocumentManagement.Data.Models
{
    public class SalaryGrade
    {
        public int SalaryGradeId { get; set; }
        public string GradeName { get; set; }
        public decimal BasicSalary { get; set; }
        public decimal MedicalAllowance { get; set; }
        public decimal HouseRent { get; set; }
        public decimal Transportation { get; set; }
        public string Others { get; set; }
        public int? IncrementDuration { get; set; } // Month
        public double? IncrementRate { get; set; }
        public DateTime LastUpdated { get; set; }

        public List<Employee> Employees { get; set; }
    }
}
