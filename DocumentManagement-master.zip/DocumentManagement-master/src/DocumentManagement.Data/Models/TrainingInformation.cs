﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DocumentManagement.Data.Models
{
    public class TrainingInformation
    {
        public int Serial { get; set; }

        public string Training { get; set; }
        public string Organization { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string Achievement { get; set; }

        public string EmployeeId { get; set; }
        public Employee Employee { get; set; }
    }
}
