﻿using DocumentManagement.Data.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DocumentManagement.Data.Models
{
    public class Transaction
    {
        public int TransactionId { get; set; }
        public string MacAddress { get; set; }
        public DateTime Timestamp { get; set; }
        public TransactionType TransactionType { get; set; }
        public Tablespace Tablespace { get; set; }
        public string RowId { get; set; }
        public int? LogId { get; set; }

        public string EmployeeId { get; set; }
        public Employee Employee { get; set; }
    }
}
