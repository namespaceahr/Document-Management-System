﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DocumentManagement.Data.Models
{
    public class WorkExperience
    {
        public int Serial { get; set; }

        public string JobTitle { get; set; }
        public string Organization { get; set; }
        public string Roles { get; set; }
        public DateTime JoiningDate { get; set; }
        public DateTime ReleaseDate { get; set; }

        public string EmployeeId { get; set; }
        public Employee Employee { get; set; }
    }
}
