﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using DocumentManagement.Data.Models;
using Microsoft.EntityFrameworkCore;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace DocumentManagement.Web.Controllers
{
    public class AccessController : Controller
    {
        private DocumentContext _context;

        public AccessController(DocumentContext context)
        {
            _context = context;
        }
        // GET: /<controller>/
        public IActionResult Index()
        {
            return View();
        }

        public JsonResult GetModules()
        {
            var modules = _context.Modules.Include(m => m.ModuleOperations);
            return Json(new { modules });
        }

        // Get assigned operations for the employees of a specific department
        public JsonResult GetDepartmentAccessList(int departmentId, int moduleId)
        {
            var assignedOperations = _context.AssignedOperations
                .Include(ao => ao.ModuleOperation)
                .Include(ao => ao.Employee)
                .Where(ao => ao.Employee.DepartmentId == departmentId && ao.ModuleOperation.ModuleId == moduleId)
                .GroupBy(ao => ao.EmployeeId);

            return Json(new { assignedOperations });
        }

        // Get assigned operations for a specific employee
        public JsonResult GetEmployeeAccessList(string employeeId)
        {
            var assignedEmployees = _context.Employees
                .Where(e => e.EmployeeId == employeeId)
                .Include(e => e.AssignedOperations)
                .ThenInclude(ao => ao.Select(o => o.ModuleOperation));
            return Json(new { assignedEmployees });
        }
    }
}
