﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using DocumentManagement.Data.Models;
using System.IO;
using static System.IO.File;
using DocumentManagement.Data.Enums;

// For more information on enabling MVC for empty projects, visit http://go.microsoft.com/fwlink/?LinkID=397860

namespace DocumentManagement.Web.Controllers
{
    public class DocumentController : Controller
    {
        private readonly DocumentContext _context;
        private readonly IHostingEnvironment _environment;
        private readonly string _sessionKeyUserId = "user";

        public DocumentController(DocumentContext context, IHostingEnvironment environment)
        {
            _context = context;
            _environment = environment;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Verify()
        {
            return View();
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpGet]
        public IActionResult GetFile(int documentId, bool base64Encoded)
        {
            var file = _context.Documents
                .Where(doc => doc.DocumentId == documentId)
                .Select(doc => doc.FileData)
                .FirstOrDefault();

            if (file == null || base64Encoded)
            {
                return Json(new { file });
            }

            return new FileContentResult(file, "application/octet-stream");
        }

        [HttpPost]
        public IActionResult Create(IFormFile file, IFormCollection form)
        {
            var newTags = form["newTags"];
            var preTags = form["preTags"];
            
            // Combine tags and filter out duplicate entries
            var metaTags = preTags.Concat(newTags).Distinct();

            Document document = new Document
            {
                Title = form["title"],
                Description = form["description"],
                Category = form["category"],
                Timestamp = DateTime.Now,
                Status = ApprovalStatus.PendingVerification,
                EmployeeId = HttpContext.Session.GetString(_sessionKeyUserId)
            };

            // Create a byte array to store the file in the database
            using (var stream = new MemoryStream())
            {
                file.CopyTo(stream);
                document.FileData = stream.ToArray();
            }

            _context.Documents.Add(document);
            ProcessMetaTags(metaTags, document);
            _context.SaveChanges();

            string fileName = $"{document.DocumentId}_{file.FileName.Replace(' ', '_')}";
            document.File = fileName;
            //Upload(file, fileName);

            AddTransaction(TransactionType.Insert, Tablespace.Document, DateTime.Now, document.DocumentId.ToString());
            _context.SaveChanges();

            return View();
        }

        public void AddTransaction(TransactionType type, Tablespace table, DateTime timestamp, string rowId)
        {
            Transaction transaction = new Transaction
            {
                TransactionType = type,
                Timestamp = timestamp,
                Tablespace = table,
                RowId = rowId,
                EmployeeId = HttpContext.Session.GetString(_sessionKeyUserId)
            };

            _context.Transactions.Add(transaction);
        }

        public void ProcessMetaTags(IEnumerable<string> tags, Document document)
        {
            List<MetaTag> metaTags = new List<MetaTag>();

            foreach (var tag in tags)
            {
                metaTags.Add(new MetaTag { Document = document, Tag = tag });
            }

            _context.MetaTags.AddRange(metaTags);
        }

        public async void Upload(IFormFile file, string fileName)
        {
            if (file != null)
            {
                var filePath = Path.Combine(_environment.WebRootPath, "documents", fileName);

                // Add the file in the application server
                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await file.CopyToAsync(stream);
                }
            }
        }

        public void UpdateCategories([FromBody]Category c)
        {
            var json = JsonConvert.SerializeObject(c, Formatting.Indented);
            var file = Path.Combine(_environment.ContentRootPath, "contents", "categories.json");

            WriteAllText(file, json);
        }

        public JsonResult GetDocumentProperties()
        {
            var file = Path.Combine(_environment.ContentRootPath, "contents", "categories.json");
            var json = ReadAllText(file);
            Category c = JsonConvert.DeserializeObject<Category>(json);

            file = Path.Combine(_environment.ContentRootPath, "contents", "suggestions.json");
            json = ReadAllText(file);
            Suggestion s = JsonConvert.DeserializeObject<Suggestion>(json);

            List<Document> docs = new List<Document>();
            docs = _context.Documents
                .Where(doc => doc.Status == ApprovalStatus.Approved)
                .Include(doc => doc.MetaTags)
                .OrderByDescending(doc => doc.Timestamp)
                .Take(10)
                .ToList();

            return Json(new { documents = docs, categories = c.Categories, suggestions = s.Suggestions });
        }

        // Get documents pending verification
        public JsonResult GetPendingVerifications()
        {
            List<Document> documents = new List<Document>();

            documents = _context.Documents
                .Where(doc => doc.Status == ApprovalStatus.PendingVerification)
                .ToList();

            return Json(new { documents });
        }

        // Get documents pending correction
        public JsonResult GetPendingCorrections()
        {
            string employeeId = HttpContext.Session.GetString(_sessionKeyUserId);

            List<Document> documents = new List<Document>();

            documents = _context.Documents
                .Where(d => d.EmployeeId == employeeId && d.Status == ApprovalStatus.PendingCorrection)
                .ToList();

            return Json(new { documents });
        }

        // Approve a document
        public void Approve(int documentId)
        {
            _context.Documents.Find(documentId)
                .Status = ApprovalStatus.Approved;
            _context.SaveChanges();
        }

        // Reject a document with note
        [HttpPost]
        public void Reject([FromBody][Bind("DocumentId,Note")] Document document)
        {
            Document doc = _context.Documents.Find(document.DocumentId);
            doc.Note = document.Note;
            doc.Status = ApprovalStatus.PendingCorrection;
            _context.SaveChanges();
        }

        // Save changes to a document after correction
        [HttpPost]
        public void Update([FromBody] Document document)
        {
            document.Status = ApprovalStatus.PendingVerification;
            _context.Entry(document).State = EntityState.Modified;
            _context.SaveChanges();
        }

        public JsonResult FilterDocuments(string category, string[] filters, DateTime startDate, DateTime endDate)
        {
            var docs = _context.Documents.AsQueryable();

            if (category != null)
            {
                docs = docs.Where(doc => doc.Category == category);
            }

            List<int> keys = new List<int>();


            if (startDate != DateTime.MinValue && endDate != DateTime.MinValue)
            {
                var transactions = _context.Transactions
                .Where(t => t.Tablespace == Tablespace.Document && t.Timestamp.Date >= startDate && t.Timestamp.Date <= endDate);


                foreach (var transaction in transactions)
                {
                    var key = Convert.ToInt32(transaction.RowId);
                    keys.Add(key);
                }

                docs = docs.Where(d => keys.Contains(d.DocumentId));
            }

            var test1 = filters != null;
            var test2 = filters.Count();

            if (filters != null && filters.Count() > 0)
            {
                foreach (var item in filters)
                {
                    docs.Where(d => d.MetaTags.Select(mt => mt.Tag).Contains(item));
                }

                //List<Document> documents = new List<Document>();

                //foreach (var key in keys)
                //{
                //    var document = docs.Find(key);
                //    var metaTags = _context.MetaTags.Where(meta => meta.DocumentId == document.DocumentId);

                //    if (metaTags == null)
                //    {
                //        continue;
                //    }

                //    foreach (var metaTag in metaTags)
                //    {
                //        if (filters.Contains(metaTag.Tag))
                //        {
                //            documents.Add(document);
                //            break;
                //        }
                //    }
                //}
            }

            var documents = docs.ToList();

            return Json(new { documents });
        }

        public JsonResult Test(string[] filters)
        {
            return Json(new { filters });
        }
    }

    public class Category
    {
        public List<string> Categories { get; set; }
    }

    class Suggestion
    {
        public List<TagSuggestion> Suggestions { get; set; }
    }

    public class TagSuggestion
    {
        public string Category { get; set; }
        public List<string> Tags { get; set; }
    }
}
