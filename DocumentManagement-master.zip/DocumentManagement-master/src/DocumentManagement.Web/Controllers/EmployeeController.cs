﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Hosting;
using DocumentManagement.Data.Models;
using Microsoft.EntityFrameworkCore;
using DocumentManagement.Web.ViewModels.PIMS;
using Microsoft.AspNetCore.Http;

namespace DocumentManagement.Web.Controllers
{
    public class EmployeeController : Controller
    {
        private DocumentContext _context;
        private IHostingEnvironment _environment;
        private string _sessionKeyUserId = "user";

        public EmployeeController(DocumentContext context, IHostingEnvironment environment)
        {
            _context = context;
            _environment = environment;
        }

        public IActionResult Index()
        {
            if (HttpContext.Session.GetString(_sessionKeyUserId) == null)
            {
                return RedirectToAction("Login", "Home");
            }

            return View();
        }

        public IActionResult Archive()
        {
            return View("Index");
        }

        [HttpGet]
        public IActionResult Details(string id)
        {
            return View("Details");
        }

        public IActionResult Add()
        {
            return View();
        }

        public IActionResult Attendance()
        {
            return View();
        }

        public IActionResult Miscellaneous()
        {
            return View();
        }

        [HttpPost]
        public void AddEmployee([FromBody] PIMS p)
        {
            var personalInformation = p.PersonalInformation;
            personalInformation.Address = p.Address;

            _context.Employees.Add(new Employee
            {
                EmployeeId = new DateTime().Millisecond.ToString(),
                PersonalInformation = personalInformation,
                AcademicInformations = p.AcademicInformations,
                WorkExperiences = p.WorkExperiences,
                TrainingInformations = p.TrainingInformations,
                References = p.References
            });

            _context.SaveChanges();
        }

        // Get Departments for attendance
        [HttpGet]
        public JsonResult GetDepartments()
        {
            var departments = _context.Departments.ToList();

            return Json(new { departments });
        }

        // Get Employees from a particular department for attendance
        [HttpGet]
        public JsonResult GetEmployeesForAttendance(int departmentId, DateTime attendanceDate)
        {
            var employees = _context.Employees
                    .Where(e => e.DepartmentId == departmentId && e.Active)
                    .Include(e => e.Designation)
                    .Include(e => e.PersonalInformation)
                    .ToList();

            var attendances = _context.Attendances
                .Where(a => a.Date.Date == attendanceDate.Date && a.Employee.DepartmentId == departmentId)
                .ToList();

            return Json(new { employees });
        }

        // Add new attendances for employees
        [HttpPost]
        public void AddNewAttendances([FromBody]List<Employee> employees)
        {
            foreach (var employee in employees)
            {
                var attendance = employee.Attendances.FirstOrDefault();

                if (attendance.AttendanceId == 0)
                {
                    _context.Attendances.Add(attendance);
                }
            }

            _context.SaveChanges();
        }

        // Update attendance status for existing attendance
        [HttpPost]
        public void UpdateAttendance([FromBody]Attendance attendance)
        {
            _context.Entry(attendance).State = EntityState.Modified;
            _context.SaveChanges();
        }

        public JsonResult GetEmployeeInformation(bool isActive)
        {
            if (isActive)
            {
                var employees = _context.Employees
                    .Where(e => e.Active)
                    .Include(e => e.Designation)
                    .Include(e => e.Department)
                    .Include(e => e.SalaryGrade);
                return Json(new { employees });
            }
            else
            {
                var employees = _context.Employees
                    .Where(e => !e.Active)
                    .Include(e => e.Designation)
                    .Include(e => e.Department)
                    .Include(e => e.SalaryGrade);
                return Json(new { employees });
            }
        }

        // Get all official and personal inforrmation of employee
        [HttpGet]
        public JsonResult GetEmployeeDetails(string employeeId)
        {
            var emp = _context.Employees
                .Where(e => e.EmployeeId == employeeId)
                .Include(e => e.Designation)
                .Include(e => e.Department)
                .Include(e => e.SalaryGrade)
                .Include(e => e.PersonalInformation)
                    .ThenInclude(p => p.Address)
                .Include(e => e.AcademicInformations)
                .Include(e => e.WorkExperiences)
                .Include(e => e.TrainingInformations)
                .Include(e => e.References)
                .SingleOrDefault();

            PIMS pims = new PIMS
            {
                Employee = emp,
                PersonalInformation = emp.PersonalInformation,
                AcademicInformations = emp.AcademicInformations,
                WorkExperiences = emp.WorkExperiences,
                TrainingInformations = emp.TrainingInformations,
                References = emp.References
            };

            return Json(new { pims });
        }

        // Get Departments, Designations and SalaryGrades
        [HttpGet]
        public JsonResult GetMiscellaneousInformation()
        {
            var departments = _context.Departments.ToList();
            var designations = _context.Designations.ToList();
            var salaryGrades = _context.SalaryGrades.ToList();

            return Json(new { departments, designations, salaryGrades });
        }

        [HttpPost]
        public void ToggleActiveStatus([FromBody] Employee employee)
        {
            employee.Active = !employee.Active;
            _context.Entry(employee).State = EntityState.Modified;
            _context.SaveChanges();
        }

        [HttpPost]
        public int AddAcademicInformation([FromBody] AcademicInformation academic)
        {
            _context.AcademicInformation.Add(academic);
            _context.SaveChanges();
            return academic.Serial;
        }

        [HttpPost]
        public int AddReference([FromBody] Reference reference)
        {
            _context.References.Add(reference);
            _context.SaveChanges();
            return reference.Serial;
        }

        [HttpPost]
        public int AddTraining([FromBody] TrainingInformation training)
        {
            _context.TrainingInformation.Add(training);
            _context.SaveChanges();
            return training.Serial;
        }

        [HttpPost]
        public int AddWorkExperience([FromBody] WorkExperience experience)
        {
            _context.WorkExperiences.Add(experience);
            _context.SaveChanges();
            return experience.Serial;
        }

        [HttpPost]
        public void UpdateAcademicInformation([FromBody] AcademicInformation academic)
        {
            _context.Entry(academic).State = EntityState.Modified;
            _context.SaveChanges();
        }

        [HttpPost]
        public void UpdateReference([FromBody] Reference reference)
        {
            _context.Entry(reference).State = EntityState.Modified;
            _context.SaveChanges();
        }

        [HttpPost]
        public void UpdateTraining([FromBody] TrainingInformation training)
        {
            _context.Entry(training).State = EntityState.Modified;
            _context.SaveChanges();
        }

        [HttpPost]
        public void UpdateWorkExperience([FromBody] WorkExperience experience)
        {
            _context.Entry(experience).State = EntityState.Modified;
            _context.SaveChanges();
        }

        [HttpPost]
        public int AddDepartment([FromBody] Department department)
        {
            _context.Departments.Add(department);
            _context.SaveChanges();
            return department.DepartmentId;
        }

        [HttpPost]
        public int AddDesignation([FromBody] Designation designation)
        {
            _context.Designations.Add(designation);
            _context.SaveChanges();
            return designation.DesignationId;
        }

        [HttpPost]
        public int AddSalaryGrade([FromBody] SalaryGrade salaryGrade)
        {
            _context.SalaryGrades.Add(salaryGrade);
            _context.SaveChanges();
            return salaryGrade.SalaryGradeId;
        }

        [HttpPost]
        public void UpdateDepartment([FromBody] Department department)
        {
            _context.Entry(department).State = EntityState.Modified;
            _context.SaveChanges();
        }

        [HttpPost]
        public void UpdateDesignation([FromBody] Designation designation)
        {
            _context.Entry(designation).State = EntityState.Modified;
            _context.SaveChanges();
        }

        [HttpPost]
        public void UpdateSalaryGrade([FromBody] SalaryGrade salaryGrade)
        {
            _context.Entry(salaryGrade).State = EntityState.Modified;
            _context.SaveChanges();
        }

        [HttpPost]
        public void UpdateEmployeeInformation([FromBody] Employee employee)
        {
            _context.Entry(employee).State = EntityState.Modified;
            _context.SaveChanges();
        }
    }
}
