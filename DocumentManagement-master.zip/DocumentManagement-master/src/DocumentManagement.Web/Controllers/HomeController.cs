﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using DocumentManagement.Data.Models;
using Microsoft.EntityFrameworkCore;
using DocumentManagement.Web.ViewModels.AccessControl;

namespace DocumentManagement.Web.Controllers
{
    public class HomeController : Controller
    {
        private DocumentContext _context;
        private string _sessionKeyUserId = "user";
        private string _sessionKeyDashboard = "dashboard";

        public HomeController(DocumentContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            if (HttpContext.Session.GetString(_sessionKeyUserId) == null)
            {
                return RedirectToAction("Login", "Home");
            }

            return View();
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(string employeeId, string password)
        {
            if ((employeeId == "2017-01-01" || employeeId == "2017-01-02") && password == null)
            {
                HttpContext.Session.SetString(_sessionKeyUserId, employeeId);

                return RedirectToAction("Index");
            }
            else
            {
                return View();
            }
        }

        [HttpGet]
        public IActionResult Logout()
        {
            HttpContext.Session.Remove(_sessionKeyUserId);
            HttpContext.Session.Remove(_sessionKeyDashboard);
            return RedirectToAction("Login");
        }

        [HttpGet]
        public JsonResult GetEmployeeDashboard()
        {
            // If no one is logged in do not process request
            string employeeId = HttpContext.Session.GetString(_sessionKeyUserId);

            if (employeeId == null)
            {
                return Json(new { });
            }

            // Load dashboard items from session
            var sessionItem = HttpContext.Session.Get<List<DashboardItem>>(_sessionKeyDashboard);

            if (sessionItem != null)
            {
                return Json(new { dashboard = sessionItem });
            }

            // Get dashboard items from database
            var dashboardItems = _context.AssignedOperations
                .Where(a => a.EmployeeId == employeeId)
                .Include(a => a.ModuleOperation)
                .ThenInclude(a => a.Module)
                .GroupBy(a => a.ModuleOperation.Module);

            List<DashboardItem> _dashboardItems = new List<DashboardItem>();

            foreach (var dashboardItem in dashboardItems)
            {
                DashboardItem _dashboardItem = new DashboardItem
                {
                    User = employeeId,
                    Module = dashboardItem.Key.ModuleName,
                    DashboardOperations = new List<DashboardOperation>()
                };

                foreach (var item in dashboardItem)
                {
                    DashboardOperation dashboardOperation = new DashboardOperation
                    {
                        OperationName = item.ModuleOperation.Operation,
                        Route = item.ModuleOperation.Routes.Split('-').FirstOrDefault()
                    };

                    _dashboardItem.DashboardOperations.Add(dashboardOperation);
                }

                _dashboardItems.Add(_dashboardItem);
            }

            HttpContext.Session.Set<List<DashboardItem>>(_sessionKeyDashboard, _dashboardItems);

            return Json(new { dashboard = _dashboardItems });
        }

        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Error()
        {
            return View();
        }
    }
}
