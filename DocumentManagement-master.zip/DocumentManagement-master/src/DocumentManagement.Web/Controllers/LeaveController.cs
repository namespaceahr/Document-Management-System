﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using DocumentManagement.Data.Models;
using DocumentManagement.Data.Enums;
using DocumentManagement.Web.ViewModels.LeaveManagement;
using Microsoft.EntityFrameworkCore;

namespace DocumentManagement.Web.Controllers
{
    public class LeaveController : Controller
    {
        private readonly DocumentContext _context;
        private readonly string _sessionKeyUserId = "user";

        public LeaveController(DocumentContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult New()
        {
            return View();
        }

        public IActionResult Approve()
        {
            return View();
        }

        public IActionResult Archive()
        {
            return View();
        }

        // Get required information when applying for a new leave
        [HttpGet]
        public JsonResult GetLeaveInformation()
        {
            string employeeId = HttpContext.Session.GetString(_sessionKeyUserId);
            Employee employee = _context.Employees
                .Include(e => e.LeaveInformation)
                .FirstOrDefault(e => e.EmployeeId == employeeId);

            string leavePeriod = GetLeavePeriod(employee);

            // Leave applications that has been granted in a given leave period
            var leaveApplications = _context.LeaveApplications
                .Where(l => l.ApplicantId == employeeId && l.LeavePeriod == leavePeriod
                    && l.Status == LeaveStatus.Granted);

            int totalVacationGranted = CalculateLeaveCount(leaveApplications,
                LeaveType.Vacation);
            int totalSickLeaveGranted = CalculateLeaveCount(leaveApplications,
                LeaveType.SickLeave);
            int totalOtherLeaveGranted = CalculateLeaveCount(leaveApplications,
                LeaveType.Other);

            LeaveYear leaveYear = new LeaveYear
            {
                Period = leavePeriod,
                LeaveInformation = employee.LeaveInformation,
                TotalVacationGranted = totalVacationGranted,
                TotalSickLeaveGranted = totalSickLeaveGranted,
                TotalOtherLeaveGranted = totalOtherLeaveGranted
            };

            return Json(new { leaveYear });
        }

        // Sum of leave granted for a particular type of leave
        private int CalculateLeaveCount(IEnumerable<LeaveApplication> leaveApplications,
            LeaveType leaveType)
        {
            int leaveCount = leaveApplications
                .Where(l => l.LeaveType == leaveType)
                .Select(l => l.Count)
                .Sum();

            return leaveCount;
        }

        // Get current leave period of employee
        private string GetLeavePeriod(Employee employee)
        {
            var today = DateTime.Today;
            var joiningDate = employee.JoiningDate;

            int leavePeriodBeginningYear = (today.Month >= joiningDate.Month)
                ? today.Year
                : today.Year - 1;
            int leavePeriodEndYear = leavePeriodBeginningYear + 1;

            int leavePeriodBeginningDate = joiningDate.Day;
            int leavePeriodEndDate = (joiningDate.Day == 1)
                ? DateTime.DaysInMonth((leavePeriodBeginningYear + 1),
                    joiningDate.AddMonths(-1).Month)
                : joiningDate.Day - 1;

            int leavePeriodBeginningMonth = joiningDate.Month;
            int leavePeriodEndMonth = (joiningDate.Day == 1)
                ? joiningDate.AddMonths(-1).Month
                : joiningDate.Month;

            string leavePeriod = $"{leavePeriodBeginningMonth} {leavePeriodBeginningDate}, " +
                $"{leavePeriodBeginningYear} - {leavePeriodEndMonth} {leavePeriodEndDate}, " +
                $"{leavePeriodEndYear}";

            var leavePeriodBeginning = new DateTime(leavePeriodBeginningYear,
                leavePeriodBeginningMonth, leavePeriodBeginningDate).ToString("yyyy-MM-dd");

            var leavePeriodEnding = new DateTime(leavePeriodEndYear, leavePeriodEndMonth,
                leavePeriodEndDate).ToString("yyyy-MM-dd");

            leavePeriod = $"{leavePeriodBeginning}~{leavePeriodEnding}";

            return leavePeriod;
        }

        // Add new application for leave
        [HttpPost]
        public void AddNewLeaveApplication([FromBody] LeaveApplication application)
        {
            application.ApplicantId = HttpContext.Session.GetString(_sessionKeyUserId);
            application.Status = LeaveStatus.Pending;
            application.Timestamp = DateTime.Now;

            _context.LeaveApplications.Add(application);
            _context.SaveChanges();
        }

        // Change leave status based on user action
        [HttpPost]
        public void UpdateLeaveApplication([FromBody] LeaveApplication application)
        {
            var attendances = PrepareAttendancesForLeave(application);

            _context.Entry(application).State = EntityState.Modified;
            _context.Attendances.AddRange(attendances);
            _context.SaveChanges();
        }

        private IEnumerable<Attendance> PrepareAttendancesForLeave(LeaveApplication application)
        {
            List<Attendance> attendances = new List<Attendance>();

            if (application.Status == LeaveStatus.Granted)
            {
                DateTime date = application.From;

                while (true)
                {
                    if (date <= application.Till)
                    {
                        attendances.Add(new Attendance
                        {
                            AttendanceStatus = AttendanceStatus.Leave,
                            Date = date,
                            EmployeeId = application.ApplicantId
                        });

                        date = date.AddDays(1);
                    }
                    else
                    {
                        break;
                    }
                }
            }

            return attendances;
        }

        // Get all leave applications of currently logged in employee
        [HttpGet]
        public JsonResult GetLeaveApplications()
        {
            string employeeId = HttpContext.Session.GetString(_sessionKeyUserId);

            var leaveApplications = _context.LeaveApplications
                .Where(l => l.ApplicantId == employeeId)
                .OrderByDescending(l => l.Timestamp);

            return Json(new { leaveApplications });
        }

        // Get all leave applications of a given status
        [HttpGet]
        public JsonResult GetAllLeaveApplications(LeaveStatus status)
        {
            var leaveApplications = _context.LeaveApplications
                .Where(l => l.Status == status)
                .OrderByDescending(l => l.Timestamp);

            return Json(new { leaveApplications });
        }
    }
}
