﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using DocumentManagement.Data.Models;
using Microsoft.EntityFrameworkCore;
using DocumentManagement.Data.Enums;
using Microsoft.AspNetCore.Http;
using System.Reflection;

namespace DocumentManagement.Web.Controllers
{
    public class PayrollController : Controller
    {
        private readonly DocumentContext _context;
        private readonly string _sessionKeyUserId = "user";

        public PayrollController(DocumentContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Create()
        {
            return View();
        }

        public JsonResult GetEmployeesWithoutPayroll(int departmentId, int year, int month)
        {
            // Employees for whom payroll has already been created
            var employeesWithExistingPayroll = _context.Payrolls
                .Where(p => p.Year == year && (int)p.Month == month)
                .Select(p => p.EmployeeId);

            // Employees for whom payroll is yet to be created
            var employees = _context.Employees
                .Where(e => e.Active && e.DepartmentId == departmentId)
                .Select(e => e.EmployeeId)
                .Except(employeesWithExistingPayroll);

            return Json(new { employees });
        }

        public JsonResult GetNewPayroll(string employeeId, int year, int month)
        {
            var employee = _context.Employees
                .Include(e => e.SalaryGrade)
                .Include(e => e.PersonalInformation)
                .FirstOrDefault(e => e.EmployeeId == employeeId);

            Gender gender = employee.PersonalInformation.Gender;
            decimal grossSalary = CalculateGrossSalary(employee.SalaryGrade);
            DateTime joiningDate = employee.JoiningDate;

            Payroll payroll = new Payroll
            {
                EmployeeId = employeeId,
                Month = (Month)month,
                Year = year,
                BasicSalary = employee.SalaryGrade.BasicSalary,
                MedicalAllowance = employee.SalaryGrade.MedicalAllowance,
                HouseRent = employee.SalaryGrade.HouseRent,
                Transportation = employee.SalaryGrade.Transportation,
                IncomeTax = CalculateIncomeTax(grossSalary, gender),
                ProvidentFund = CalculateProvidentFund(grossSalary, joiningDate),
                UnpaidLeave = CalculateUnpaidLeave()
            };

            return Json(new { payroll });
        }

        private decimal CalculateGrossSalary(SalaryGrade salaryGrade)
        {
            decimal grossSalary = (salaryGrade.BasicSalary + salaryGrade.HouseRent + 
                salaryGrade.MedicalAllowance + salaryGrade.Transportation);

            return grossSalary;
        }

        private decimal CalculateIncomeTax(decimal grossSalary, Gender gender)
        {
            decimal yearlySalary = grossSalary * 12;
            decimal incomeTaxLimit = (gender == Gender.Female) ? 400000 : 350000;
            decimal exceededAmount = yearlySalary - incomeTaxLimit;
            decimal incomeTaxPercentage = 0.10m;

            decimal incomeTax = (exceededAmount > 0) 
                ? ((exceededAmount * incomeTaxPercentage) / 12) 
                : 0;

            return incomeTax;
        }

        private decimal CalculateProvidentFund(decimal grossSalary, DateTime joiningDate)
        {
            // Employment duration in month
            var employmentDuration = Math.Floor((double)((DateTime.Now - joiningDate).Days / 30));
            // Provision period in month
            int provisionPeriod = 6;
            decimal providentFundPercentage = 0.05m;

            decimal providentFund = (employmentDuration > provisionPeriod)
                ? (grossSalary * providentFundPercentage)
                : 0;

            return providentFund;
        }

        private decimal CalculateUnpaidLeave()
        {
            decimal unpaidLeave = 500;
            return unpaidLeave;
        }

        [HttpPost]
        public void AddNewPayroll([FromBody]Payroll payroll)
        {
            payroll.CreatorId = HttpContext.Session.GetString(_sessionKeyUserId);
            payroll.CreatedAt = DateTime.Now;
            _context.Payrolls.Add(payroll);
            _context.SaveChanges();
        }

        public JsonResult GetExistingPayrolls(string employeeId)
        {
            var payrolls = _context.Payrolls
                .Where(p => p.EmployeeId == employeeId)
                .Include(p => p.Employee)
                .ThenInclude(e => e.PersonalInformation);

            return Json(new { payrolls });
        }

        public JsonResult GetEmployeesFromDepartment(int departmentId)
        {
            var employees = _context.Employees
                .Where(e => e.DepartmentId == departmentId)
                .Select(e => e.EmployeeId);

            return Json(new { employees });
        }
    }
}
