﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using DocumentManagement.Data.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Http;
using DocumentManagement.Data.Enums;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace DocumentManagement.Web.Controllers
{
    public class ReceiptController : Controller
    {
        private readonly DocumentContext _context;
        private readonly string _sessionKeyUserId = "user";

        public ReceiptController(DocumentContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Create()
        {
            return View();
        }

        public IActionResult Details(int voucherId)
        {
            return View();
        }

        public IActionResult Verify()
        {
            return View();
        }

        public IActionResult Correct(int id)
        {
            return View();
        }

        // Add new receipt
        [HttpPost]
        public void Create([FromBody] Receipt receipt)
        {
            // Find last receipt of the same month
            Receipt lastReceipt = _context.Receipts
                .Where(r => r.Date.Year == receipt.Date.Year
                    && r.Date.Month == receipt.Date.Month)
                .LastOrDefault();

            receipt.ReceiptNo = (lastReceipt == null) ? 1 : lastReceipt.ReceiptNo + 1;
            receipt.CreatorId = HttpContext.Session.GetString(_sessionKeyUserId);
            receipt.Status = ApprovalStatus.PendingVerification;
            _context.Receipts.Add(receipt);
            _context.SaveChanges();
        }

        public IActionResult Get(int receiptId)
        {
            Receipt receipt = _context.Receipts
                .Include(r => r.Procurer)
                    .ThenInclude(procurer => procurer.PersonalInformation)
                .Where(r => r.ReceiptId == receiptId)
                .SingleOrDefault();

            return Json(new { receipt });
        }

        // Get approved receipts
        public JsonResult GetApprovals()
        {
            List<Receipt> receipts = new List<Receipt>();

            receipts = _context.Receipts
                .Where(receipt => receipt.Status == ApprovalStatus.Approved)
                .Include(receipt => receipt.Procurer)
                    .ThenInclude(procurer => procurer.PersonalInformation)
                .ToList();

            return Json(new { receipts });
        }

        // Get receipts pending verification
        public JsonResult GetPendingVerifications()
        {
            List<Receipt> receipts = new List<Receipt>();

            receipts = _context.Receipts
                .Where(receipt => receipt.Status == ApprovalStatus.PendingVerification)
                .Include(receipt => receipt.Procurer)
                    .ThenInclude(procurer => procurer.PersonalInformation)
                .ToList();

            return Json(new { receipts });
        }

        // Get receipts pending correction
        public JsonResult GetPendingCorrections()
        {
            string employeeId = HttpContext.Session.GetString(_sessionKeyUserId);

            List<Receipt> receipts = new List<Receipt>();

            receipts = _context.Receipts
                .Where(r => r.CreatorId == employeeId && r.Status == ApprovalStatus.PendingCorrection)
                .Include(receipt => receipt.Procurer)
                    .ThenInclude(procurer => procurer.PersonalInformation)
                .ToList();

            return Json(new { receipts });
        }

        // Approve a receipt
        public void Approve(int receiptId)
        {
            _context.Receipts.Find(receiptId)
                .Status = ApprovalStatus.Approved;
            _context.SaveChanges();
        }

        // Reject a receipt with note
        [HttpPost]
        public void Reject([FromBody][Bind("ReceiptId,Note")] Receipt receipt)
        {
            Receipt r = _context.Receipts.Find(receipt.ReceiptId);
            r.Note = receipt.Note;
            r.Status = ApprovalStatus.PendingCorrection;
            _context.SaveChanges();
        }

        // Save changes to a receipt after correction
        [HttpPost]
        public void Update([FromBody] Receipt receipt)
        {
            receipt.Status = ApprovalStatus.PendingVerification;
            _context.Entry(receipt).State = EntityState.Modified;
            _context.SaveChanges();
        }

        // Get department and employee list
        [HttpGet]
        public JsonResult GetReceiptProperties()
        {
            var employees = _context.Employees
                .Include(ep => ep.PersonalInformation)
                .Select(e => new { e.EmployeeId,
                    e.PersonalInformation.FirstName, e.PersonalInformation.LastName });

            return Json(new { employees });
        }
    }
}
