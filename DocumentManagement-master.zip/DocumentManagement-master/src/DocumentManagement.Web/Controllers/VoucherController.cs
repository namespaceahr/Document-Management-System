﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using DocumentManagement.Data.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Http;
using DocumentManagement.Data.Enums;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace DocumentManagement.Web.Controllers
{
    public class VoucherController : Controller
    {
        private readonly DocumentContext _context;
        private readonly string _sessionKeyUserId = "user";

        public VoucherController(DocumentContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Create()
        {
            return View();
        }

        public IActionResult Details(int voucherId)
        {
            return View();
        }

        public IActionResult Verify()
        {
            return View();
        }

        public IActionResult Correct(int id)
        {
            return View();
        }

        // Add new voucher
        [HttpPost]
        public void Create([FromBody] Voucher voucher)
        {
            // Find last voucher of the same month
            Voucher lastVoucher = _context.Vouchers
                .Where(v => v.Date.Year == voucher.Date.Year
                    && v.Date.Month == voucher.Date.Month)
                .LastOrDefault();

            voucher.VoucherNo = (lastVoucher == null) ? 1 : lastVoucher.VoucherNo + 1;
            voucher.CreatorId = HttpContext.Session.GetString(_sessionKeyUserId);
            voucher.Status = ApprovalStatus.PendingVerification;
            _context.Vouchers.Add(voucher);
            _context.SaveChanges();
        }

        public IActionResult Get(int voucherId)
        {
            Voucher voucher = _context.Vouchers
                .Include(v => v.Procurer)
                    .ThenInclude(procurer => procurer.PersonalInformation)
                .Include(v => v.Department)
                .Where(v => v.VoucherId == voucherId)
                .SingleOrDefault();

            return Json(new { voucher });
        }

        // Get approved vouchers
        public JsonResult GetApprovals()
        {
            List<Voucher> vouchers = new List<Voucher>();

            vouchers = _context.Vouchers
                .Where(voucher => voucher.Status == ApprovalStatus.Approved)
                .Include(voucher => voucher.Procurer)
                    .ThenInclude(procurer => procurer.PersonalInformation)
                .Include(voucher => voucher.Department)
                .ToList();

            return Json(new { vouchers });
        }

        // Get vouchers pending verification
        public JsonResult GetPendingVerifications()
        {
            List<Voucher> vouchers = new List<Voucher>();

            vouchers = _context.Vouchers
                .Where(voucher => voucher.Status == ApprovalStatus.PendingVerification)
                .Include(voucher => voucher.Procurer)
                    .ThenInclude(procurer => procurer.PersonalInformation)
                .Include(voucher => voucher.Department)
                .ToList();

            return Json(new { vouchers });
        }

        // Get vouchers pending correction
        public JsonResult GetPendingCorrections()
        {
            string employeeId = HttpContext.Session.GetString(_sessionKeyUserId);

            List<Voucher> vouchers = new List<Voucher>();

            vouchers = _context.Vouchers
                .Where(v => v.CreatorId == employeeId && v.Status == ApprovalStatus.PendingCorrection)
                .Include(voucher => voucher.Procurer)
                    .ThenInclude(procurer => procurer.PersonalInformation)
                .Include(voucher => voucher.Department)
                .ToList();

            return Json(new { vouchers });
        }

        // Approve a voucher
        public void Approve(int voucherId)
        {
            _context.Vouchers.Find(voucherId)
                .Status = ApprovalStatus.Approved;
            _context.SaveChanges();
        }

        // Reject a voucher with note
        [HttpPost]
        public void Reject([FromBody][Bind("VoucherId,Note")] Voucher voucher)
        {
            Voucher v = _context.Vouchers.Find(voucher.VoucherId);
            v.Note = voucher.Note;
            v.Status = ApprovalStatus.PendingCorrection;
            _context.SaveChanges();
        }

        // Save changes to a voucher after correction
        [HttpPost]
        public void Update([FromBody] Voucher voucher)
        {
            voucher.Status = ApprovalStatus.PendingVerification;
            _context.Entry(voucher).State = EntityState.Modified;
            _context.SaveChanges();
        }

        // Get department and employee list
        [HttpGet]
        public JsonResult GetVoucherProperties()
        {
            var departments = _context.Departments.ToList();

            var employees = _context.Employees
                .Include(ep => ep.PersonalInformation)
                .Select(e => new { e.EmployeeId,
                    e.PersonalInformation.FirstName, e.PersonalInformation.LastName });

            return Json(new { departments , employees});
        }
    }
}
