﻿using System.Collections.Generic;

namespace DocumentManagement.Web.ViewModels.AccessControl
{
    class DashboardItem
    {
        public string User { get; set; }
        public string Module { get; set; }
        public List<DashboardOperation> DashboardOperations { get; set; }
    }
}
