﻿namespace DocumentManagement.Web.ViewModels.AccessControl
{
    class DashboardOperation
    {
        public string OperationName { get; set; }
        public string Route { get; set; }
    }
}
