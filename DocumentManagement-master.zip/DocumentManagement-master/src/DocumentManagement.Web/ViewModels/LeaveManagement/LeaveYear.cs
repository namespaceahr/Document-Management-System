﻿using DocumentManagement.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DocumentManagement.Web.ViewModels.LeaveManagement
{
    public class LeaveYear
    {
        public string Period { get; set; }
        public LeaveInformation LeaveInformation { get; set; }

        public int TotalSickLeaveGranted { get; set; }
        public int TotalVacationGranted { get; set; }
        public int TotalOtherLeaveGranted { get; set; }

        // Total applicable leave for a leave year
        public int TotalApplicableLeave
        {
            get
            {
                return LeaveInformation.Vacation + LeaveInformation.SickLeave
                    + LeaveInformation.OtherLeave;
            }
        }

        // Total leave that has been granted in a leave year
        public int TotalLeaveGranted
        {
            get
            {
                return TotalVacationGranted + TotalSickLeaveGranted
                    + TotalOtherLeaveGranted;
            }
        }

        // Available leave to apply for in a leave year
        public int TotalAvailableLeave
        {
            get
            {
                int availableLeave = TotalApplicableLeave - TotalLeaveGranted;
                return availableLeave > 0 ? availableLeave : 0;
            }
        }
    }
}
