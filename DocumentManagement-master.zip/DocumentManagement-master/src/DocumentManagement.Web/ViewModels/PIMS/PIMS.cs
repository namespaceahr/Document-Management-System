﻿using DocumentManagement.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DocumentManagement.Web.ViewModels.PIMS
{
    public class PIMS
    {
        public Employee Employee { get; set; }
        public PersonalInformation PersonalInformation { get; set; }
        public Address Address { get; set; }
        public List<AcademicInformation> AcademicInformations { get; set; }
        public List<WorkExperience> WorkExperiences { get; set; }
        public List<TrainingInformation> TrainingInformations { get; set; }
        public List<Reference> References { get; set; }
    }
}
