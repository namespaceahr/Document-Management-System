﻿app.controller('AccessController', ['$scope', '$http', function ($scope, $http) {

    $scope.employeeId = "";

    $http.get('/Employee/GetDepartments').then(function (response) {
        $scope.departments = response.data.departments;

    }, function (error) {
        console.log(error);
    });

    $http.get('/Access/GetModules').then(function (response) {
        $scope.modules = response.data.modules;

    }, function (error) {
        console.log(error);
    });

    $scope.getAccessList = function () {
        if ($scope.employeeId) {
            $http.get('/Access/GetEmployeeAccessList', {
                params: { empployeeId: $scope.employeeId }
            }).then(function (response) {
                $scope.assignedEmployees = response.data.assignedEmployees;
                console.log($scope.assignedEmployees);

            }, function (error) {
                console.log(error);
            });
        }
        else {
            var departmentId = $('#department').val();
            var moduleId = $('#module').val();

            $http.get('/Access/GetDepartmentAccessList', {
                params: { departmentId, moduleId }
            }).then(function (response) {
                console.log(response.data);
                //$scope.assignedEmployees = response.data.assignedEmployees;
                //console.log($scope.assignedEmployees);

            }, function (error) {
                console.log(error);
            });
        }
    }

}]);