﻿app.controller('AttendanceController', ['$scope', '$http', function ($scope, $http) {

    var array = window.location.pathname.split("/");
    var action = array[array.length - 1];
    var isActive = (action == "Archive") ? false : true;

    $http.get('/Employee/GetDepartments').then(function (response) {
        $scope.departments = response.data.departments;

    }, function (error) {
        console.log(error);
    });

    $scope.getEmployeesForAttendance = function () {
        var departmentId = $('#department').val();
        var attendanceDate = $('#date').val();

        $http.get('/Employee/GetEmployeesForAttendance', {
            params: { departmentId, attendanceDate }
        }).then(function (response) {
            $scope.employees = response.data.employees;
        }, function (error) {
            console.log(error);
        });
    }

    // Get previous attendance sheet or generate new attendance sheet
    $scope.getAttendanceSheet = function () {
        var departmentId = $('#department').val();
        var attendanceDate = $('#date').val();
        var currentDate = new Date().toISOString().substr(0, 10);

        if (attendanceDate == currentDate) {
            // Today's attendances
            $http.get('/Employee/GetEmployeesForAttendance', {
                params: { departmentId, attendanceDate }
            }).then(function (response) {
                $scope.employees = response.data.employees;

                // Create a new attendance for each employee who are not on leave
                angular.forEach($scope.employees, function (obj) {
                    if (obj["Attendances"] == null) {
                        $scope.isNewAttendance = true;

                        var attendance = {
                            Date: new Date().toISOString().substr(0, 10),
                            CheckIn: null,
                            CheckOut: null,
                            AttendanceStatus: 0,
                            EmployeeId: obj["EmployeeId"]
                        }

                        obj.Attendances = [];
                        obj.Attendances.push(attendance);
                    }
                });

            }, function (error) {
                console.log(error);
            });
        }
        else {
            // Previous attendances
            $scope.isNewAttendance = false;
            $scope.getEmployeesForAttendance();
        }
    }

    $scope.addNewAttendances = function () {
        var data = $scope.employees;
        $http.post('/Employee/AddNewAttendances', data);
        
        // Reload attendance sheet
        $scope.getEmployeesForAttendance();
    }

    $scope.setAttendanceStatus = function (attendance, attendanceStatusCode) {
        // Make change on client
        attendance.AttendanceStatus = attendanceStatusCode;

        // Send changes to server if this is an existing entry
        // Otherwise the changes will be saved when submitting the attendance sheet
        if (attendance.AttendanceId) {
            $http.post('/Employee/UpdateAttendance', attendance);
        }
    }

    $scope.test = function () {
        console.log($scope.employees);
    }
}]);