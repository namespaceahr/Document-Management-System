﻿var app = angular.module('DocumentManagement', ['ui.toggle']);

app.controller('DefaultController', ['$scope', '$http', '$location', function ($scope, $http, $location) {

    $scope.dashboard = null;

    if ($scope.dashboard == null) {
        $http.get('/Home/GetEmployeeDashboard').then(function (response) {
            console.log("Getting dashboard items....");
            $scope.dashboard = response.data.dashboard;
            console.log($scope.dashboard);

        }, function (error) {
            console.log(error);
        });
    }

    $scope.logout = function () {
        $scope.dashboard = null;
    }

}]);