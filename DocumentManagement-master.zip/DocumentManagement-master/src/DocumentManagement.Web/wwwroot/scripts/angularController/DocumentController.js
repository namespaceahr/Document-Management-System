﻿app.controller('DocumentController', ['$scope', '$http', '$sce', function ($scope, $http, $sce) {

    $scope.fileContent = '';
    $scope.fileContentTrusted = '';

    $scope.getDocuments = function () {
        $http.get('/Document/GetDocumentProperties').then(function (response) {
            console.log(response);

            $scope.categories = response.data.categories;
            $scope.suggestions = response.data.suggestions;
            $scope.documents = response.data.documents;
            $scope.loadCategorizedTagsFilter('');

            $scope.tags = [];
            angular.forEach($scope.suggestions, function (obj) {
                $scope.tags = $scope.tags.concat(obj.Tags);
            });

            $scope.processDocuments();

        }, function (error) {
            console.log(error);
        });
    }

    $scope.getDocumentProperties = function () {
        $http.get('/Document/GetDocumentProperties').then(function (response) {
            console.log(response);

            $scope.categories = response.data.categories;
            $scope.suggestions = response.data.suggestions;
            $scope.loadCategorizedTagsFilter('');

            $scope.tags = [];
            angular.forEach($scope.suggestions, function (obj) {
                $scope.tags = $scope.tags.concat(obj.Tags);
            });

        }, function (error) {
            console.log(error);
        });
    }

    $scope.getFile = function (obj) {
        $scope.fileContent = 'http://localhost:5000/Document/GetFile?documentId=' +
            obj.DocumentId + '&base64Encoded=false';
        $scope.fileContentTrusted = $sce.trustAsResourceUrl($scope.fileContent);
        console.log($scope.fileContent);
        console.log($scope.fileContentTrusted);

        return;

        $http.get('/Document/GetFile', {
            params: { documentId: obj.DocumentId, base64Encoded: true }
        }).then(function (response) {
            console.log(response.data.file);
            
            var file = new Blob([response.data.file], { type: 'application/pdf' });
            var fileURL = URL.createObjectURL(file);
            $scope.pdfContent = $sce.trustAsResourceUrl(fileURL);

            console.log(fileURL);
        }, function (error) {
            console.log(error);
        });

        //$http.get('https://cdn4.iconfinder.com/data/icons/ionicons/512/icon-image-128.png', {
        //    responseType: 'arraybuffer'
        //}).then(function (response) {
        //    console.log(response);
        //    var file = new Blob([response], { type: "application/pdf" });
        //    console.log(file);
        //}, function (error) {
        //    console.log(error);
        //});
    }

    $scope.getPendingVerifications = function () {
        $http.get('/Document/GetPendingVerifications').then(function (response) {
            $scope.documents = response.data.documents;
            console.log($scope.documents);
            $scope.processDocuments();

        }, function (error) {
            console.log(error);
        });
    }

    $scope.getPendingCorrections = function () {
        $http.get('/Document/GetPendingCorrections').then(function (response) {
            $scope.documents = response.data.documents;
            $scope.processDocuments();

        }, function (error) {
            console.log(error);
        });
    }

    $scope.approveDocument = function (obj, index) {
        $http.get('/Document/Approve', {
            params: { documentId: obj.DocumentId }
        }).then(function (response) {
            $scope.documents.splice(index, 1);
            //$scope.getPendingVerifications();
        }, function (error) {
            console.log(error);
        });
    }

    $scope.rejectDocument = function (obj, index) {
        $http.post('/Document/Reject', obj).then(function (response) {
            $scope.documents.splice(index, 1);
            //$scope.getPendingVerifications();

        }, function (error) {
            console.log(error);
        });
    }

    $scope.isNewCategory = false;
    $scope.newCategory = null;
    $scope.addNewDoc = false;
    $scope.staticCol = 12;
    $scope.advancedSearch = false;
    $scope.isDateRange = true;
    $scope.searchFilterCol = 4;

    $scope.getFilteredDocuments = function () {
        var startDate = $scope.isDateRange ? 
            $('#interval').data('daterangepicker').startDate.format('YYYY-MM-DD') : null;
        var endDate = $scope.isDateRange ? 
            $('#interval').data('daterangepicker').endDate.format('YYYY-MM-DD') : null;
        var filters = $('#searchFilter').val();
        var category = $scope.categorySearch;

        console.log(startDate);
        console.log(endDate);
        console.log(filters);
        console.log(category);

        $http.get('/Document/FilterDocuments', {
            params: { category, filters, startDate, endDate }
        }).then(function (response) {
            console.log(response.data);
            $scope.documents = response.data.documents;
            $scope.processDocuments();
        }, function (error) {
            console.log(error);
        });
    }

    // Load category specific tag suggestions when searching documents
    $scope.loadCategorizedTagsFilter = function (category) {
        $scope.categorizedTagsFilter = [];

        if (category == '') {
            angular.forEach($scope.suggestions, function (obj) {
                $scope.categorizedTagsFilter = $scope.categorizedTagsFilter.concat(obj.Tags);
            });
        }
        else {
            angular.forEach($scope.suggestions, function (obj) {
                if (obj.Category === category) {
                    $scope.categorizedTagsFilter = obj.Tags;
                }
            });
        }
    };

    // Load category specific tag suggestions when adding new document
    $scope.loadCategorizedTagsSuggestion = function (category) {
        $scope.categorizedTagsSuggestion = [];

        angular.forEach($scope.suggestions, function (obj) {
            if (obj.Category === category) {
                $scope.categorizedTagsSuggestion = obj.Tags;
            }
        });
    };

    $scope.processMetaTags = function () {
        var predefinedTags = [];
        $('#preTags:checked').each(function (index) {
            predefinedTags[index] = $(this).val();
        });

        var newTags = $('#newTags').val(); // array

        var tags = predefinedTags.concat(newTags); // array
        console.log(tags);

        $('#metaTags').val(tags);
    }

    $scope.processDocuments = function () {
        angular.forEach($scope.documents, function (obj) {
            obj["showEdit"] = false;
            obj["link"] = "http://localhost:5000/documents/" + obj.File;
            obj["pdf"] = "http://docs.google.com/gview?url=" + obj.link + "&embedded=true";
            obj["viewPdf"] = $sce.trustAsResourceUrl(obj.pdf);
        });
    }

    $scope.toggleAddDocument = function () {
        if ($scope.addNewDoc) {
            document.getElementById("toggleAddDoc").className = "glyphicon glyphicon-plus";
            $scope.staticCol = 12;
        }
        else {
            document.getElementById("toggleAddDoc").className = "glyphicon glyphicon-minus";
            $scope.staticCol = 8;
        }
        $scope.addNewDoc = $scope.addNewDoc ? false : true;

    };

    $scope.toggleAddCategory = function () {
        $scope.isNewCategory = $scope.isNewCategory ? false : true;
    };

    $scope.toggleAdvancedSearch = function () {
        $scope.advancedSearch = $scope.advancedSearch ? false : true;
    }

    $scope.resizeSearchTags = function () {
        if($scope.isDateRange) {
            $scope.searchFilterCol = 4;
        }
        else {
            $scope.searchFilterCol = 6;
        }
    }
   
    $scope.addNewCategory = function () {
        if ($scope.newCategory !== null) {
            $scope.categories.push($scope.newCategory);

            var newCategories = {
                "categories": $scope.categories
            }

            var post = $http({
                method: "POST",
                url: "/Document/UpdateCategories",
                dataType: 'json',
                data: newCategories,
                headers: { "Content-Type": "application/json" }
            });

            post.success(function (data, status) {
                //$window.alert("Saved!");
            });

            post.error(function (data, status) {
                //$window.alert(data.Message);
            });

            $scope.toggleAddCategory();
            $scope.newCategory = null;
        }
    }

    // Editing of documents pending for correction
    $scope.oldvalue = '';

    // Toggle edit
    $scope.toggleEdit = function (obj) {
        obj.showEdit = !obj.showEdit;
        if (obj.showEdit) {
            $scope.oldvalue = angular.copy(obj);
        }
    };

    // Cancel edit
    $scope.cancelEdit = function (obj) {
        var index = $scope.documents.indexOf(obj);
        $scope.oldvalue.showEdit = false;
        $scope.documents[index] = $scope.oldvalue;
    };

    // Confirm edit
    $scope.sendForApproval = function (obj, index) {
        $http.post('/Document/Update', obj).then(function (response) {
            $scope.documents.splice(index, 1);
            //$scope.getPendingCorrections();
        });
    }
}]);