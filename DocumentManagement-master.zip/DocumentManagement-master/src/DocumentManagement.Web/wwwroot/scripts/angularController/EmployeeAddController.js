﻿app.controller('EmployeeAddController', ['$scope', '$http', function ($scope, $http) {

    $http.get('/Employee/GetMiscellaneousInformation').then(function (response) {
        console.log(response.data);

        $scope.departments = response.data.departments;
        $scope.designations = response.data.designations;
        $scope.salaryGrades = response.data.salaryGrades;

    }, function (error) {
        console.log(error);
    });

    $http.get('/contents/area.json').then(function (response) {
        console.log(response.data);
        $scope.area = response.data.divisions;
        $scope.loadDivisions($scope.area);

    }, function (error) {
        console.log(error);
    });

    $http.get('/contents/scholar.json').then(function (response) {
        $scope.scholar = response.data.exams;
        $scope.loadExams($scope.scholar);

    }, function (error) {
        console.log(error);
    });

    //post objects
    $scope.emp = {};
    $scope.personalInfo = {};
    $scope.address = {};

    //address model
    $scope.address.District = null;
    $scope.address.Thana = null;

    //address dropdown data
    $scope.divisions = [];
    $scope.districts = [];
    $scope.thanas = [];

    //academic dropdown data
    $scope.exams = [];
    $scope.groups = [];

    $scope.loadDivisions = function (divisions) {
        for (var division in divisions) {
            $scope.divisions.push(division);
        }
        console.log($scope.divisions);
    }

    $scope.loadDistricts = function (division) {
        var districts = $scope.area[division]['districts'];
        $scope.districts = [];
        $scope.address.District = null;
        $scope.thanas = [];
        $scope.address.Thana = null;

        for (var district in districts) {
            $scope.districts.push(district);
        }
        console.log($scope.districts);
    }

    $scope.loadThanas = function (division, district) {
        $scope.thanas = [];
        $scope.address.Thana = null;

        $scope.thanas = $scope.area[division]['districts'][district]['thanas'];
        console.log($scope.thanas);
    }

    $scope.loadExams = function (exams) {
        for (var exam in exams) {
            $scope.exams.push(exam);
        }
        console.log($scope.exams);
    }

    $scope.loadGroups = function (exam) {
        $scope.newObj.Group = null;
        $scope.groups = $scope.scholar[exam]['groups'];
        console.log($scope.groups);
    }

    //academicList
    $scope.academicList = [];
    $scope.newObj = {};
    $scope.isNewRowAcademic = false;

    $scope.toggleAdd = function(){
        $scope.isNewRowAcademic = $scope.isNewRowAcademic ? false : true;
    }
    $scope.addNewAcademic = function (obj) {
        $scope.academicList.push(obj);
        console.log($scope.academicList);
        $scope.toggleAdd();
        $scope.newObj = {};
    };
    $scope.removeAcademic = function (obj) {
        $scope.academicList.pop(obj);
        console.log($scope.academicList);
    };

    //workExperienceList
    $scope.workExperienceList = [];
    $scope.newWorkExperience = {};
    $scope.isNewRowWorkExperience = false;

    $scope.toggleAddWorkExperience = function () {
        $scope.isNewRowWorkExperience = $scope.isNewRowWorkExperience ? false : true;
    }
    $scope.addNewWorkExperience = function (obj) {
        $scope.workExperienceList.push(obj);
        console.log($scope.workExperienceList);
        $scope.toggleAddWorkExperience();
        $scope.newWorkExperience = {};
    };
    $scope.removeWorkExperience = function (obj) {
        $scope.workExperienceList.pop(obj);
        console.log($scope.workExperienceList);
    };

    //trainingInformationList
    $scope.trainingInformationList = [];
    $scope.newTrainingInformation = {};
    $scope.isNewRowTrainingInformation = false;

    $scope.toggleAddTrainingInformation = function () {
        $scope.isNewRowTrainingInformation = $scope.isNewRowTrainingInformation ? false : true;
    }
    $scope.addNewTrainingInformation = function (obj) {
        $scope.trainingInformationList.push(obj);
        console.log($scope.trainingInformationList);
        $scope.toggleAddTrainingInformation();
        $scope.newTrainingInformation = {};
    };
    $scope.removeTrainingInformation = function (obj) {
        $scope.trainingInformationList.pop(obj);
        console.log($scope.trainingInformationList);
    };

    //referenceList
    $scope.referenceList = [];
    $scope.newReference = {};
    $scope.isNewRowReference = false;

    $scope.toggleAddReference = function () {
        $scope.isNewRowReference = $scope.isNewRowReference ? false : true;
    }
    $scope.addNewReference = function (obj) {
        $scope.referenceList.push(obj);
        console.log($scope.referenceList);
        $scope.toggleAddReference();
        $scope.newReference = {};
    };
    $scope.removeReference = function (obj) {
        $scope.referenceList.pop(obj);
        console.log($scope.referenceList);
    };

    //Add New Employee
    $scope.addEmployee = function () {
        var newEmployee = {
            "employee": $scope.emp,
            "personalInformation": $scope.personalInfo,
            "address": $scope.address,
            "academicInformations": $scope.academicList,
            "workExperiences": $scope.workExperienceList,
            "trainingInformations": $scope.trainingInformationList,
            "references": $scope.referenceList
        }

        console.log(newEmployee);
        $http.post('/Employee/AddEmployee', newEmployee);
    };
}]);