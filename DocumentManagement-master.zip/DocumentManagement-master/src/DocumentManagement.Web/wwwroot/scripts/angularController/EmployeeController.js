﻿app.controller('EmployeeController', ['$scope', '$http', function ($scope, $http) {

    var array = window.location.pathname.split("/");
    var action = array[array.length - 1];
    var isActive = (action == "Archive") ? false : true;

    $http.get('/Employee/GetEmployeeInformation', {
        params: { isActive }
    }).then(function (response) {
        $scope.employees = response.data.employees;

    }, function (error) {
        console.log(error);
    });

    $scope.toggleActiveStatus = function (item, index) {
        // Remove the item from server
        $http.post('/Employee/ToggleActiveStatus', item);

        // Remove the item from client
        $scope.employees.splice(index, 1);
    }

}]);