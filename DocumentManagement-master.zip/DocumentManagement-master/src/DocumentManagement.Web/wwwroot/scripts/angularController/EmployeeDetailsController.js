﻿app.controller('EmployeeDetailsController', ['$scope', '$http', "$filter", function ($scope, $http, $filter) {

    var array = window.location.pathname.split("/");
    var employeeId = array[array.length - 1];

    $http.get('/Employee/GetEmployeeDetails/', {
        params: { employeeId }
    }).then(function (response) {
        console.log(response.data);
        $scope.pims = response.data.pims;

        angular.forEach($scope.pims.AcademicInformations, function (obj) {
            obj["editAcademic"] = false;
        });

        angular.forEach($scope.pims.WorkExperiences, function (obj) {
            obj["editExperience"] = false;
            obj["JoiningDate"] = $filter('date')(obj["JoiningDate"], "MM/dd/yyyy");
            obj["ReleaseDate"] = $filter('date')(obj["ReleaseDate"], "MM/dd/yyyy");
        });

        angular.forEach($scope.pims.TrainingInformations, function (obj) {
            obj["editTraining"] = false;
            obj["StartDate"] = $filter('date')(obj["StartDate"], "MM/dd/yyyy");
            obj["EndDate"] = $filter('date')(obj["EndDate"], "MM/dd/yyyy");
        });

        angular.forEach($scope.pims.References, function (obj) {
            obj["editReference"] = false;
        });

    }, function (error) {
        console.log(error);
    });

    //post objects
    $scope.emp = {};
    $scope.personalInfo = {};
    $scope.address = {};

    //address dropdown data
    $scope.divisions = [];
    $scope.districts = [];
    $scope.thanas = [];

    //academic dropdown data
    $scope.exams = [];
    $scope.groups = [];
   

    $scope.loadDivisions = function (divisions) {
        for (var division in divisions) {
            $scope.divisions.push(division);
        }
        console.log($scope.divisions);
    }

    $scope.loadDistricts = function (division) {
        var districts = $scope.area[division]['districts'];
        $scope.districts = [];
        $scope.pims.Employee.PerosnalInformation.Address.District = null;
        $scope.thanas = [];
        $scope.pims.Employee.PerosnalInformation.Address.Thana = null;

        for (var district in districts) {
            $scope.districts.push(district);
        }
        console.log($scope.districts);
    }

    $scope.loadThanas = function (division, district) {
        $scope.thanas = [];
        $scope.pims.Employee.PerosnalInformation.Address.Thana = null;

        $scope.thanas = $scope.area[division]['districts'][district]['thanas'];
        console.log($scope.thanas);
    }

    $scope.loadExams = function (exams) {
        for (var exam in exams) {
            $scope.exams.push(exam);
        }
        console.log($scope.exams);
    }

    $scope.loadGroups = function (exam) {
        $scope.newObj.Group = null;
        $scope.groups = $scope.scholar[exam]['groups'];
        console.log($scope.groups);
    }

    //EmployeeInformation
    $scope.editEmployeeInfo = false;
    $scope.oldValueEmployeeInfo = {};
    $scope.toggleEditEmployeeInfo = function () {
        // Get all departments, designations and salary grade when clicked on edit
        if (!$scope.departments || !$scope.designations || !$scope.salaryGrades) {
            $http.get('/Employee/GetMiscellaneousInformation').then(function (response) {
                console.log(response.data);

                $scope.departments = response.data.departments;
                $scope.designations = response.data.designations;
                $scope.salaryGrades = response.data.salaryGrades;

            }, function (error) {
                console.log(error);
            });
        }

        if (!$scope.editEmployeeInfo) {
            $scope.oldValueEmployeeInfo = angular.copy($scope.pims.Employee);
        }

        $scope.editEmployeeInfo = !$scope.editEmployeeInfo;
    }

    $scope.cancelButtonEmployee = function () {
        $scope.pims.Employee = $scope.oldValueEmployeeInfo;
        $scope.oldValueEmployeeInfo = {};
        $scope.editEmployeeInfo = !$scope.editEmployeeInfo;
    }

    $scope.updateEmployeeInfo = function (obj) {
        console.log(obj);
        //$http.post('/Employee/UpdateEmployeeInformation', obj);

        $scope.editEmployeeInfo = false;
    }

    //academicList
    $scope.academicList = [];
    $scope.newObj = {};
    $scope.isNewRowAcademic = false;

    $scope.toggleAdd = function(){
        $scope.isNewRowAcademic = $scope.isNewRowAcademic ? false : true;
    }
    $scope.addNewAcademic = function (obj) {
        $scope.academicList.push(obj);
        console.log($scope.academicList);
        $scope.toggleAdd();
        $scope.newObj = {};
    };
    $scope.removeAcademic = function (obj) {
        $scope.academicList.pop(obj);
        console.log($scope.academicList);
    };

    //workExperienceList
    $scope.workExperienceList = [];
    $scope.newWorkExperience = {};
    $scope.isNewRowWorkExperience = false;

    $scope.toggleAddWorkExperience = function () {
        $scope.isNewRowWorkExperience = $scope.isNewRowWorkExperience ? false : true;
    }
    $scope.addNewWorkExperience = function (obj) {
        $scope.workExperienceList.push(obj);
        console.log($scope.workExperienceList);
        $scope.toggleAddWorkExperience();
        $scope.newWorkExperience = {};
    };
    $scope.removeWorkExperience = function (obj) {
        $scope.workExperienceList.pop(obj);
        console.log($scope.workExperienceList);
    };

    //trainingInformationList
    $scope.trainingInformationList = [];
    $scope.newTrainingInformation = {};
    $scope.isNewRowTrainingInformation = false;

    $scope.toggleAddTrainingInformation = function () {
        $scope.isNewRowTrainingInformation = $scope.isNewRowTrainingInformation ? false : true;
    }
    $scope.addNewTrainingInformation = function (obj) {
        $scope.trainingInformationList.push(obj);
        console.log($scope.trainingInformationList);
        $scope.toggleAddTrainingInformation();
        $scope.newTrainingInformation = {};
    };
    $scope.removeTrainingInformation = function (obj) {
        $scope.trainingInformationList.pop(obj);
        console.log($scope.trainingInformationList);
    };

    //referenceList
    $scope.referenceList = [];
    $scope.newReference = {};
    $scope.isNewRowReference = false;

    $scope.toggleAddReference = function () {
        $scope.isNewRowReference = $scope.isNewRowReference ? false : true;
    }
    $scope.addNewReference = function (obj) {
        $scope.referenceList.push(obj);
        console.log($scope.referenceList);
        $scope.toggleAddReference();
        $scope.newReference = {};
    };
    $scope.removeReference = function (obj) {
        $scope.referenceList.pop(obj);
        console.log($scope.referenceList);
    };

    //Add New Employee
    $scope.addEmployee = function () {
        var newEmployee = {
            "employee": $scope.emp,
            "personalInformation": $scope.personalInfo,
            "address": $scope.address,
            "academicInformations": $scope.academicList,
            "workExperiences": $scope.workExperienceList,
            "trainingInformations": $scope.trainingInformationList,
            "references": $scope.referenceList
        }

        console.log(newEmployee);

        $http.post('/Employee/AddEmployee', newEmployee).success(function () {

        });
    };

    //toggle Academic Edit
    $scope.oldvalueacademic = '';
    $scope.addRowAcademic = false;
    $scope.newObjAcademic = {};

    $scope.toggleEditAcademic = function (obj) {
        obj.editAcademic = !obj.editAcademic;
        if (obj.editAcademic) {
            oldvalueacademic = angular.copy(obj);
        }
    };
    $scope.toggleAddAcademic = function () {
        $scope.addRowAcademic = !$scope.addRowAcademic;
    }

    $scope.addNewAcademic = function (obj) {
        $scope.HttpPost("/Employee/AddAcademicInformation", obj);
        
        obj.editAcademic = false;
        $scope.pims.AcademicInformations.push(obj);
        $scope.newObjAcademic = {};
        $scope.toggleAddAcademic();
    };

    // Cancel Academic edit
    $scope.cancelButtonAcademic = function (obj) {
        var index = $scope.pims.AcademicInformations.indexOf(obj);
        oldvalueacademic.editAcademic = false;
        $scope.pims.AcademicInformations[index] = oldvalueacademic;
    };

    // Update Academic
    $scope.updateAcademic = function (obj) {
        console.log(obj);
        $http.post('/Employee/UpdateAcademicInformation', obj);

        obj.editAcademic = false;
    }

    // Toggle WorkExperience Edit
    $scope.oldvalueworkexperience = '';
    $scope.addRowWorkExperience = false;
    $scope.newObjWorkExperience = {};

    $scope.toggleEditworkExperience = function (obj) {
        obj.editExperience = !obj.editExperience;
        if (obj.editExperience) {
            oldvalueworkexperience = angular.copy(obj);
        }
    };

    $scope.toggleAddWorkExperience = function () {
        $scope.addRowWorkExperience = !$scope.addRowWorkExperience;
    }

    // Add work experience
    $scope.addNewWorkExperience = function (obj) {
        $scope.HttpPost("/Employee/AddWorkExperience", obj);
        
        obj.editExperience = false;
        $scope.pims.WorkExperiences.push(obj);
        $scope.newObjWorkExperience = {};
        $scope.toggleAddWorkExperience();
    };

    // Cancel WorkExperience edit
    $scope.cancelButtonworkExperience = function (obj) {
        var index = $scope.pims.WorkExperiences.indexOf(obj);
        oldvalueworkexperience.editExperience = false;
        $scope.pims.WorkExperiences[index] = oldvalueworkexperience;
    };

    // Update WorkExperience
    $scope.updateworkExperience = function (obj) {
        $http.post('/Employee/UpdateWorkExperience', obj);

        obj.editExperience = false;
    };

    // Toggle Training Edit
    $scope.oldvaluetraining = '';

    $scope.toggleEditTraining = function (obj) {
        obj.editTraining = !obj.editTraining;
        if (obj.editTraining) {
            oldvaluetraining = angular.copy(obj);
        }
    };

    // Cancel Training edit
    $scope.cancelButtonTraining = function (obj) {
        var index = $scope.pims.TrainingInformations.indexOf(obj);
        oldvaluetraining.editTraining= false;
        $scope.pims.TrainingInformations[index] = oldvaluetraining;
    };

    // Update Training
    $scope.updateTraining = function (obj) {
        console.log(obj.StartDate);
        console.log(typeof obj.StartDate);
        $http.post('/Employee/UpdateTraining', obj);

        obj.editTraining = false;
    };

    // Toggle Reference Edit
    $scope.oldvaluereference = '';

    $scope.toggleEditReference = function (obj) {
        obj.editReference = !obj.editReference;
        if (obj.editReference) {
            oldvaluereference = angular.copy(obj);
        }
    };

    // Reference edit cancel
    $scope.cancelButtonReference = function (obj) {
        var index = $scope.pims.References.indexOf(obj);
        oldvaluereference.editReference = false;
        $scope.pims.References[index] = oldvaluereference;
    };

    // Update reference
    $scope.updateReference = function (obj) {
        $http.post('/Employee/UpdateReference', obj);

        obj.editReference = false;
    };

    // Toggle Training Add
    $scope.oldvaluetraining = '';
    $scope.addRowTraining = false;
    $scope.newObjTraining = {};

    $scope.toggleAddNewTraining = function () {
        $scope.addRowTraining = !$scope.addRowTraining;
    }
    // Add New Training
    $scope.addNewTraining = function (obj) {
        $scope.HttpPost("/Employee/AddTraining", obj);
        console.log(obj.StartDate);
        console.log(typeof obj.StartDate);
        obj.editTraining = false;
        $scope.pims.TrainingInformations.push(obj);
        $scope.newObjTraining = {};
        $scope.toggleAddNewTraining();
    };

    // Toggle Reference Add
    $scope.oldvaluereference = '';
    $scope.addRowReference = false;
    $scope.newObjReference = {};

    $scope.toggleAddNewReference = function () {
        $scope.addRowReference = !$scope.addRowReference;
    }

    // Add New Reference
    $scope.addNewReference = function (obj) {
        $scope.HttpPost("/Employee/AddReference", obj);

        obj.editReference = false;
        $scope.addRowReference = false;
        $scope.pims.References.push(obj);
        $scope.newObjReference = {};
    };

    // Toggle edit of Personal Information
    $scope.toggleEditPersonalInfo = function () {
        if (!$scope.area) {
            $http.get('/contents/area.json').then(function (response) {
                console.log(response.data);
                $scope.area = response.data.divisions;
                $scope.loadDivisions($scope.area);

            }, function (error) {
                console.log(error);
            });
        }

        $scope.editPersonalInfo = !$scope.editPersonalInfo;
    }

    // Update department of employee
    $scope.setNewDepartment = function (departmentName) {
        angular.forEach($scope.departments, function (obj) {
            if (obj["DepartmentName"] == departmentName) {
                $scope.pims.Employee.Department = obj;
            }
        });
        console.log($scope.pims.Employee.Department);
    }

    // Update designation of employee
    $scope.setNewDesignation = function (designationName) {
        angular.forEach($scope.designations, function (obj) {
            if (obj["DesignationName"] == designationName) {
                $scope.pims.Employee.Designation = obj;
            }
        });
        console.log($scope.pims.Employee.Designation);
    }

    // Update salary grade of employee
    $scope.setNewSalaryGrade = function (salaryGradeName) {
        angular.forEach($scope.salaryGrades, function (obj) {
            if (obj["GradeName"] == salaryGradeName) {
                $scope.pims.Employee.SalaryGrade = obj;
            }
        });
        console.log($scope.pims.Employee.SalaryGrade);
    }

    // Add new information for employee
    $scope.HttpPost = function (url, obj) {
        obj.EmployeeId = employeeId;

        $http.post(url, obj).then(function (response) {
            obj.Serial = response.data;
        });
    }
}]);
