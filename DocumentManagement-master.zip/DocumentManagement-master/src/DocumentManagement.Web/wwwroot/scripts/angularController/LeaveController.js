﻿app.controller('LeaveController', ['$scope', '$http', function ($scope, $http) {

    $scope.detailView = false;
    $scope.leaveApplication = {};
    $scope.newApplication = {};
    $scope.errorMessage = '';

    // Get required information when applying for a new leave
    $scope.getLeaveInformation = function () {
        $http.get('/Leave/GetLeaveInformation').then(function (response) {
            $scope.leaveYear = response.data.leaveYear;
        }, function (error) {
            console.log(error);
        });
    }

    // Add new application for leave
    $scope.addNewLeaveApplication = function (applicaton) {
        if (!$scope.checkAvailableLeave()) {
            return;
        }

        applicaton.LeavePeriod = $scope.leaveYear.Period;

        $http.post('/Leave/AddNewLeaveApplication', applicaton).then(function (response) {
            window.location.assign("/Leave");
        }, function (error) {
            console.log(error);
        });
    };

    // Change leave status based on user action
    $scope.updateLeaveApplication = function (applicaton, newStatus) {
        var currentStatus = applicaton.Status;
        applicaton.Status = newStatus;

        $http.post('/Leave/UpdateLeaveApplication', applicaton).then(function (response) {
            $scope.toggleDetailsView();
        }, function (error) {
            console.log(error);
            applicaton.Status = currentStatus;
        });
    };

    $scope.checkAvailableLeave = function () {
        var total, granted, available, leave;

        switch ($scope.newApplication.LeaveType) {
            case '1':
                total = $scope.leaveYear.LeaveInformation.SickLeave;
                granted = $scope.leaveYear.TotalSickLeaveGranted;
                available = (total - granted);
                leave = 'Sick Leave';

                break;
            case '2':
                total = $scope.leaveYear.LeaveInformation.Vacation;
                granted = $scope.leaveYear.TotalVacationGranted;
                available = (total - granted);
                leave = 'Vacation';

                break;
        }

        if (available == 0) {
            $scope.errorMessage = 'You do not have any ' + leave + ' available.';
            return false;
        } else {
            var difference_ms = Math.abs($scope.newApplication.From - $scope.newApplication.Till);
            var difference_day = Math.round(difference_ms / (1000 * 60 * 60 * 24));

            if (available < difference_day) {
                $scope.errorMessage = 'You have only ' + available + ' days of ' + leave;
                return false;
            } else {
                return true;
            }
        }
    };

    $scope.clearErrorMessage = function () {
        $scope.errorMessage = '';
    }

    // Get all leave applications of currently logged in employee
    $scope.getLeaveApplications = function () {
        $http.get('/Leave/GetLeaveApplications').then(function (response) {
            $scope.leaveApplications = response.data.leaveApplications;
        }, function (error) {
            console.log(error);
        });
    };

    // Get all leave applications of a given status
    $scope.getAllLeaveApplications = function (status) {
        $http.get('/Leave/GetAllLeaveApplications', {
            params: { status }
        }).then(function (response) {
            $scope.leaveApplications = response.data.leaveApplications;
        }, function (error) {
            console.log(error);
        });
    };

    // Toogle between application list and details

    $scope.toggleDetailsView = function () {
        $scope.detailView = $scope.detailView ? false : true;
        $scope.leaveApplication = {};
    };

    $scope.showDetails = function (obj) {
        $scope.toggleDetailsView();
        $scope.leaveApplication = obj;
    };
}]);