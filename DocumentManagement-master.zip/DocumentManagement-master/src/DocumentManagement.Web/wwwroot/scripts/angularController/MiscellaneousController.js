﻿app.controller('MiscellaneousController', ['$scope', '$http', function ($scope, $http) {

    $http.get('/Employee/GetMiscellaneousInformation').then(function (response) {
        console.log(response.data);

        $scope.departments = response.data.departments;
        $scope.designations = response.data.designations;
        $scope.salaryGrades = response.data.salaryGrades;

        angular.forEach($scope.departments, function (obj) {
            obj["editMode"] = false;
        });

        angular.forEach($scope.designations, function (obj) {
            obj["editMode"] = false;
        });

        angular.forEach($scope.salaryGrades, function (obj) {
            obj["editMode"] = false;
        });

    }, function (error) {
        console.log(error);
    });

    // Departments
    // Toggle Department Edit
    $scope.oldvaluedepartment = '';
    $scope.addRowDepartment = false;
    $scope.newObjDepartment = {};

    $scope.toggleEditDepartment = function (obj) {
        obj.editMode = !obj.editMode;
        if (obj.editMode) {
            oldvaluedepartment = angular.copy(obj);
        }
    };

    $scope.toggleAddDepartment = function () {
        $scope.addRowDepartment = !$scope.addRowDepartment;
    }

    // Add Department
    $scope.addNewDepartment = function (obj) {
        $http.post('/Employee/AddDepartment', obj).then(function (response) {
            obj.DepartmentId = response.data;
        });

        obj.editMode = false;
        $scope.departments.push(obj);
        $scope.newObjDepartment = {};
        $scope.toggleAddDepartment();
    };

    // Cancel Department edit
    $scope.cancelButtonDepartment = function (obj) {
        var index = $scope.departments.indexOf(obj);
        oldvaluedepartment.editMode = false;
        $scope.departments[index] = oldvaluedepartment;
    };

    // Update Department
    $scope.updateDepartment = function (obj) {
        $http.post('/Employee/UpdateDepartment', obj);

        obj.editMode = false;
    };

    // Designations
    // Toggle Designation Edit
    $scope.oldvaluedesignation = '';
    $scope.addRowDesignation = false;
    $scope.newObjDesignation = {};

    $scope.toggleEditDesignation = function (obj) {
        obj.editMode = !obj.editMode;
        if (obj.editMode) {
            oldvaluedesignation = angular.copy(obj);
        }
    };

    $scope.toggleAddDesignation = function () {
        $scope.addRowDesignation = !$scope.addRowDesignation;
    }

    // Add Designation
    $scope.addNewDesignation = function (obj) {
        $http.post('/Employee/AddDesignation', obj).then(function (response) {
            obj.DesignationId = response.data;
        });

        obj.editMode = false;
        $scope.designations.push(obj);
        $scope.newObjDesignation = {};
        $scope.toggleAddDesignation();
    };

    // Cancel Designation edit
    $scope.cancelButtonDesignation = function (obj) {
        var index = $scope.designations.indexOf(obj);
        oldvaluedesignation.editMode = false;
        $scope.designations[index] = oldvaluedesignation;
    };

    // Update Designation
    $scope.updateDesignation = function (obj) {
        $http.post('/Employee/UpdateDesignation', obj);

        obj.editMode = false;
    };

    // SalaryGrade
    // Toggle SalaryGrade Edit
    $scope.oldvaluesalarygrade = '';
    $scope.addRowSalaryGrade = false;
    $scope.newObjSalaryGrade = {};

    $scope.toggleEditSalaryGrade = function (obj) {
        obj.editMode = !obj.editMode;
        if (obj.editMode) {
            oldvaluesalarygrade = angular.copy(obj);
        }
    };

    $scope.toggleAddSalaryGrade = function () {
        $scope.addRowSalaryGrade = !$scope.addRowSalaryGrade;
    }

    // Add SalaryGrade
    $scope.addNewSalaryGrade = function (obj) {
        obj.LastUpdated = new Date().toISOString().substr(0, 10);

        $http.post('/Employee/AddSalaryGrade', obj).then(function (response) {
            obj.SalaryGradeId = response.data;
        });

        obj.editMode = false;
        $scope.salaryGrades.push(obj);
        $scope.newObjSalaryGrade = {};
        $scope.toggleAddSalaryGrade();
    };

    // Cancel SalaryGrade edit
    $scope.cancelButtonSalaryGrade = function (obj) {
        var index = $scope.salaryGrades.indexOf(obj);
        oldvaluesalarygrade.editMode = false;
        $scope.salaryGrades[index] = oldvaluesalarygrade;
    };

    // Update SalaryGrade
    $scope.updateSalaryGrade = function (obj) {
        obj.LastUpdated = new Date().toISOString().substr(0, 10);
        $http.post('/Employee/UpdateSalaryGrade', obj);
        obj.editMode = false;
    };

}]);