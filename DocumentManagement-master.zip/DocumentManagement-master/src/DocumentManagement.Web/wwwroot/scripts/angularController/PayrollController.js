﻿app.controller('PayrollController', ['$scope', '$http', function ($scope, $http) {

    $scope.payrollDate = "";
    $scope.newPayment = false;
    $scope.miscellaneousItems = [];
    $scope.totalOther = 0;
    $scope.oldItemAmount = 0;
    $scope.detailView = false;
    $scope.existingPayroll = {};
    $scope.month = [
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    ];

    $http.get('/Employee/GetDepartments').then(function (response) {
        $scope.departments = response.data.departments;
    }, function (error) {
        console.log(error);
    });

    $scope.getEmployeesWithoutPayroll = function () {

        var departmentId = $('#department').val();

        if ($scope.payrollDate) {
            var year = $scope.payrollDate.getFullYear();
        } else {
            return;
        }

        if ($scope.payrollDate) {
            var month = $scope.payrollDate.getMonth();
        } else {
            return;
        }

        $http.get('/Payroll/GetEmployeesWithoutPayroll', {
            params: { departmentId, year, month }
        }).then(function (response) {
            $scope.employees = response.data.employees;
        }, function (error) {
            console.log(error);
        });
    };

    $scope.getNewPayroll = function () {
        var year = $scope.payrollDate.getFullYear();
        var month = $scope.payrollDate.getMonth();
        var employeeId = $('#employee').val();

        $http.get('/Payroll/GetNewPayroll', {
            params: { employeeId, year, month }
        }).then(function (response) {
            $scope.payroll = response.data.payroll;
            console.log($scope.payroll);
        }, function (error) {
            console.log(error);
        });
    };

    $scope.addNewPayroll = function (payroll) {
        console.log("Deleting hashkey and editmode");
        angular.forEach($scope.miscellaneousItems, function (item) {
            delete item['$$hashKey'];
            delete item['editMode'];
        });

        payroll.Others = JSON.stringify($scope.miscellaneousItems);

        $http.post('/Payroll/AddNewPayroll', payroll).then(function (response) {
            window.location.assign("/Payroll/Index");
        }, function (error) {
            console.log(error);
        });
    };

    $scope.getEmployeesFromDepartment = function () {
        var departmentId = $('#department').val();

        $http.get('/Payroll/GetEmployeesFromDepartment', {
            params: { departmentId }
        }).then(function (response) {
            $scope.employees = response.data.employees;
            console.log($scope.employees);
            console.log(response);
        }, function (error) {
            console.log(error);
        });
    };

    $scope.getExistingPayrolls = function () {

        var employeeId = $('#employee').val();

        $http.get('/Payroll/GetExistingPayrolls', {
            params: { employeeId }
        }).then(function (response) {
            $scope.payrolls = response.data.payrolls;
        }, function (error) {
            console.log(error);
        });
    };

    // Toggle add
    $scope.toggleAdd = function () {
        $scope.newPayment = $scope.newPayment ? false : true;
        $scope.newObj = {};
    }

    // miscellaneous items

    $scope.addItem = function (obj) {
        $scope.toggleAdd();
        $scope.newObj = {};
        obj.editMode = false;
        $scope.miscellaneousItems.push(obj);
        $scope.totalOther += obj.Amount;
    };

    // Toggle edit
    $scope.oldValueItem = '';

    $scope.toggleEditItem = function (obj) {
        $scope.oldItemAmount = obj.Amount;
        obj.editMode = !obj.editMode;
        if (obj.editMode) {
            oldValueItem = angular.copy(obj);
        }
    };

    $scope.removeItem = function (obj) {
        var index = $scope.miscellaneousItems.indexOf(obj);
        $scope.miscellaneousItems.splice(index, 1);
        $scope.totalOther -= obj.Amount;
    };

    // Update item
    $scope.updateItem = function (obj) {
        $scope.totalOther -= $scope.oldItemAmount;
        obj.editMode = false;
        $scope.totalOther += obj.Amount;
    };
    // Cancel item edit
    $scope.cancelItem = function (obj) {
        var index = $scope.miscellaneousItems.indexOf(obj);
        oldValueItem.editMode = false;
        $scope.miscellaneousItems[index] = oldValueItem;

    };

    $scope.toggleDetailsView = function () {
        $scope.detailView = $scope.detailView ? false : true;
        $scope.existingPayroll = {};
    }

    $scope.showDetails = function (obj) {
        $scope.toggleDetailsView();
        $scope.existingPayroll = obj;
        $scope.existingPayroll.Others = JSON.parse($scope.existingPayroll.Others);
    }
}]);