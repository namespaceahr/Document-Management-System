﻿app.controller('ReceiptController', ['$scope', '$http', function ($scope, $http) {

    $scope.Initilize = function () {
        $scope.receipt = {};
        $scope.payment = {};
        $scope.newAdditem = {};
        $scope.addItemList = [];
        $scope.isNewItemRow = false;
        $scope.grandTotal = 0;
        $scope.oldItemTotal = 0;
    }
   
    $scope.Initilize();

    $scope.getReceiptProperties = function () {
        $http.get('/Receipt/GetReceiptProperties').then(function (response) {
            $scope.employees = response.data.employees;
        }, function (error) {
            console.log(error);
        });
    }

    $scope.getReceipt = function () {
        var array = window.location.pathname.split("/");
        var receiptId = array[array.length - 1];

        $http.get('/Receipt/Get', {
            params: { receiptId }
        }).then(function (response) {
            $scope.receipt = response.data.receipt;
            $scope.receipt.Date = $scope.receipt.Date.substr(0, 10);
            $scope.addItemList = JSON.parse($scope.receipt.Items);
            $scope.payment = JSON.parse($scope.receipt.PaymentInformation);

            angular.forEach($scope.addItemList, function (obj) {
                $scope.grandTotal += obj.Total;
            });
        }, function (error) {
            console.log(error);
        });

        $scope.getReceiptProperties();
    }

    $scope.getApprovals = function () {
        $http.get('/Receipt/GetApprovals').then(function (response) {
            $scope.receipts = response.data.receipts;
        }, function (error) {
            console.log(error);
        });
    }

    $scope.getPendingVerifications = function () {
        $http.get('/Receipt/GetPendingVerifications').then(function (response) {
            $scope.receipts = response.data.receipts;
        }, function (error) {
            console.log(error);
        });
    }

    $scope.getPendingCorrections = function () {
        $http.get('/Receipt/GetPendingCorrections').then(function (response) {
            $scope.receipts = response.data.receipts;
        }, function (error) {
            console.log(error);
        });
    }

    $scope.addNewReceipt = function (obj) {
        angular.forEach($scope.addItemList, function (item) {
            delete item['$$hashKey'];
        });

        var items = JSON.stringify($scope.addItemList);
        obj.Items = items;
        var payment = $scope.receipt.PaymentType == 1 ? null : JSON.stringify($scope.payment);
        obj.PaymentInformation = payment;
        console.log(obj);

        $http.post('/Receipt/Create', obj).then(function (response) {
            $scope.Initilize();
        });
    }

    $scope.updateReceipt = function (obj) {
        angular.forEach($scope.addItemList, function (item) {
            delete item['$$hashKey'];
        });

        var items = JSON.stringify($scope.addItemList);
        obj.Items = items;
        var payment = $scope.receipt.PaymentType == 1 ? null : JSON.stringify($scope.payment);
        obj.PaymentInformation = payment;

        $http.post('/Receipt/Update', obj).then(function (response) {
            window.location.assign("/Receipt/Create");
        });
    }

    $scope.approve = function (obj) {
        $http.get('/Receipt/Approve', {
            params: { receiptId: obj.ReceiptId }
        }).then(function (response) {
            window.location.assign("/Receipt/Verify");
        }, function (error) {
            console.log(error);
        });
    }

    $scope.reject = function (obj) {
        $http.post('/Receipt/Reject', obj).then(function (response) {
            window.location.assign("/Receipt/Verify");
        }, function (error) {
            console.log(error);
        });
    }

    // Receipt items

    $scope.addNewItem = function (obj) {
        $scope.toggleAdd();
        $scope.newObj = {};
        obj.editmode = false;
        $scope.addItemList.push(obj);
        $scope.grandTotal += obj.Total;
    };

    $scope.removeItem = function (obj) {
        var index = $scope.addItemList.indexOf(obj);
        $scope.addItemList.splice(index, 1);
        $scope.grandTotal -= obj.Total;
    };

    $scope.calculateTotal = function (obj) {
        obj.Total = (obj.Quantity ? obj.Quantity : 0) * (obj.UnitPrice ? obj.UnitPrice : 0);
    }

    // Toggle add
    $scope.toggleAdd = function () {
        $scope.isNewItemRow = $scope.isNewItemRow ? false : true;
        $scope.newObj = {};
    }

    // Toggle edit
    $scope.oldValueItem = '';

    $scope.toggleEditItem = function (obj) {
        $scope.oldItemTotal = obj.Total;
        obj.editMode = !obj.editMode;
        if (obj.editMode) {
            oldValueItem = angular.copy(obj);
        }
    };

    // Cancel item edit
    $scope.cancelItem = function (obj) {
        var index = $scope.addItemList.indexOf(obj);
        oldValueItem.editMode = false;
        $scope.addItemList[index] = oldValueItem;
    };

    // Update item
    $scope.updateItem = function (obj) {
        $scope.grandTotal -= $scope.oldItemTotal;
        obj.editMode = false;
        $scope.grandTotal += obj.Total;
    };

    $scope.togglePanel = function () {
        $scope.isDetails = $scope.isDetails ? false : true;
    };
}]);