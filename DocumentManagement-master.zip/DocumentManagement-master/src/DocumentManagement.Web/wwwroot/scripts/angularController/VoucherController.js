﻿app.controller('VoucherController', ['$scope', '$http', function ($scope, $http) {

    $scope.Initilize = function () {
        $scope.voucher = {};
        $scope.newAdditem = {};
        $scope.addItemList = [];
        $scope.isNewItemRow = false;
        $scope.grandTotal = 0;
        $scope.oldItemTotal = 0;
    }
   
    $scope.Initilize();

    $scope.getVoucherProperties = function () {
        $http.get('/Voucher/GetVoucherProperties').then(function (response) {
            $scope.departments = response.data.departments;
            $scope.employees = response.data.employees;
        }, function (error) {
            console.log(error);
        });
    }

    $scope.getVoucher = function () {
        var array = window.location.pathname.split("/");
        var voucherId = array[array.length - 1];

        $http.get('/Voucher/Get', {
            params: { voucherId }
        }).then(function (response) {
            $scope.voucher = response.data.voucher;
            $scope.voucher.Date = $scope.voucher.Date.substr(0, 10);
            $scope.addItemList = JSON.parse($scope.voucher.Items);

            angular.forEach($scope.addItemList, function (obj) {
                $scope.grandTotal += obj.Total;
            });
        }, function (error) {
            console.log(error);
        });

        $scope.getVoucherProperties();
    }

    $scope.getApprovals = function () {
        $http.get('/Voucher/GetApprovals').then(function (response) {
            $scope.vouchers = response.data.vouchers;
        }, function (error) {
            console.log(error);
        });
    }

    $scope.getPendingVerifications = function () {
        $http.get('/Voucher/GetPendingVerifications').then(function (response) {
            $scope.vouchers = response.data.vouchers;
        }, function (error) {
            console.log(error);
        });
    }

    $scope.getPendingCorrections = function () {
        $http.get('/Voucher/GetPendingCorrections').then(function (response) {
            $scope.vouchers = response.data.vouchers;
        }, function (error) {
            console.log(error);
        });
    }

    $scope.addNewVoucher = function (obj) {
        angular.forEach($scope.addItemList, function (item) {
            delete item['$$hashKey'];
        });

        var items = JSON.stringify($scope.addItemList);
        obj.Items = items;
        console.log(obj);

        $http.post('/Voucher/Create', obj).then(function (response) {
            $scope.Initilize();
        });
    }

    $scope.updateVoucher = function (obj) {
        angular.forEach($scope.addItemList, function (item) {
            delete item['$$hashKey'];
        });

        var items = JSON.stringify($scope.addItemList);
        obj.Items = items;

        $http.post('/Voucher/Update', obj).then(function (response) {
            window.location.assign("/Voucher/Create");
        });
    }

    $scope.approve = function (obj) {
        $http.get('/Voucher/Approve', {
            params: { voucherId: obj.VoucherId }
        }).then(function (response) {
            window.location.assign("/Voucher/Verify");
        }, function (error) {
            console.log(error);
        });
    }

    $scope.reject = function (obj) {
        $http.post('/Voucher/Reject', obj).then(function (response) {
            window.location.assign("/Voucher/Verify");
        }, function (error) {
            console.log(error);
        });
    }

    // Voucher items

    $scope.addNewItem = function (obj) {
        $scope.toggleAdd();
        $scope.newObj = {};
        obj.editmode = false;
        $scope.addItemList.push(obj);
        $scope.grandTotal += obj.Total;
    };

    $scope.removeItem = function (obj) {
        var index = $scope.addItemList.indexOf(obj);
        $scope.addItemList.splice(index, 1);
        $scope.grandTotal -= obj.Total;
    };

    $scope.calculateTotal = function (obj) {
        obj.Total = (obj.Quantity ? obj.Quantity : 0) * (obj.UnitPrice ? obj.UnitPrice : 0);
    }

    // Toggle add
    $scope.toggleAdd = function () {
        $scope.isNewItemRow = $scope.isNewItemRow ? false : true;
        $scope.newObj = {};
    }

    // Toggle edit
    $scope.oldValueItem = '';

    $scope.toggleEditItem = function (obj) {
        $scope.oldItemTotal = obj.Total;
        obj.editMode = !obj.editMode;
        if (obj.editMode) {
            oldValueItem = angular.copy(obj);
        }
    };

    // Cancel item edit
    $scope.cancelItem = function (obj) {
        var index = $scope.addItemList.indexOf(obj);
        oldValueItem.editMode = false;
        $scope.addItemList[index] = oldValueItem;
    };

    // Update item
    $scope.updateItem = function (obj) {
        $scope.grandTotal -= $scope.oldItemTotal;
        obj.editMode = false;
        $scope.grandTotal += obj.Total;
    };

    $scope.togglePanel = function () {
        $scope.isDetails = $scope.isDetails ? false : true;
    };
}]);